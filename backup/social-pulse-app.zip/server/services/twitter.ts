import { TwitterApi } from 'twitter-api-v2';
import { storage } from '../storage';

// Check if API keys are present
if (!process.env.TWITTER_API_KEY || !process.env.TWITTER_API_SECRET) {
  console.error('Twitter API keys are missing. Please set TWITTER_API_KEY and TWITTER_API_SECRET environment variables.');
}

// Create a Twitter client with consumer keys only
let twitterClient: TwitterApi;
try {
  twitterClient = new TwitterApi({
    appKey: process.env.TWITTER_API_KEY!,
    appSecret: process.env.TWITTER_API_SECRET!,
  });
} catch (error) {
  console.error('Failed to initialize Twitter API client:', error);
  // Create a dummy client that will throw appropriate errors when used
  twitterClient = {} as TwitterApi;
}

console.log('Twitter API initialized with:', {
  appKeyExists: !!process.env.TWITTER_API_KEY,
  appSecretExists: !!process.env.TWITTER_API_SECRET,
  callbackUrlExists: !!process.env.TWITTER_CALLBACK_URL,
});

export const TwitterService = {
  /**
   * Generate OAuth URL for Twitter authorization
   * @returns Twitter OAuth URL and temporary tokens
   */
  async generateAuthLink() {
    const callbackUrl = process.env.TWITTER_CALLBACK_URL!;
    
    if (!callbackUrl) {
      console.error('Twitter callback URL is not configured');
      throw new Error('Twitter callback URL is not configured');
    }
    
    console.log('Attempting to generate Twitter auth link with callback URL:', callbackUrl);
    
    try {
      // Generate auth link for the callback URL
      const authLink = await twitterClient.generateAuthLink(callbackUrl, { 
        linkMode: 'authorize'
        // Twitter API v2 OAuth 1.0a does not support scopes in the same way as OAuth 2.0
      });
      
      console.log('Twitter auth link generated successfully:', {
        url: authLink.url ? 'VALID_URL' : 'MISSING_URL',
        oauth_token: authLink.oauth_token ? 'VALID_TOKEN' : 'MISSING_TOKEN',
        oauth_token_secret: authLink.oauth_token_secret ? 'VALID_SECRET' : 'MISSING_SECRET',
      });
      
      return {
        authUrl: authLink.url,
        oauth_token: authLink.oauth_token,
        oauth_token_secret: authLink.oauth_token_secret,
      };
    } catch (error: any) {
      console.error('Error generating Twitter auth link:', error);
      
      // More detailed error information
      if (error.code === 401 || error.code === 32) {
        throw new Error('Twitter API authentication failed. Please check your API keys.');
      } else if (error.message && error.message.includes('callback')) {
        throw new Error('Invalid Twitter callback URL. Please check your TWITTER_CALLBACK_URL setting.');
      }
      
      throw new Error('Failed to generate Twitter authorization link: ' + (error.message || 'Unknown error'));
    }
  },

  /**
   * Complete the OAuth flow with the callback data
   * @param userId - ID of the user connecting their Twitter account
   * @param oauthToken - OAuth token from callback
   * @param oauthVerifier - OAuth verifier from callback
   * @param oauthTokenSecret - Previously stored OAuth token secret
   * @returns Connected Twitter account details
   */
  async handleCallback(
    userId: number,
    oauthToken: string,
    oauthVerifier: string,
    oauthTokenSecret: string
  ) {
    try {
      // Create a temporary client for token exchange
      const tempClient = new TwitterApi({
        appKey: process.env.TWITTER_API_KEY!,
        appSecret: process.env.TWITTER_API_SECRET!,
        accessToken: oauthToken,
        accessSecret: oauthTokenSecret,
      });

      // Exchange the request tokens for access tokens
      const { client: loggedClient, accessToken, accessSecret } = 
        await tempClient.login(oauthVerifier);
      
      // Get the user's Twitter profile
      const twitterUser = await loggedClient.v2.me({ 
        'user.fields': ['profile_image_url', 'name', 'username'] 
      });
      
      // Store the Twitter account in the database
      const twitterAccount = await storage.createSocialAccount({
        userId,
        platform: 'twitter',
        accountId: twitterUser.data.id,
        accountName: twitterUser.data.username, // Use username as accountName
        accessToken,
        accessTokenSecret: accessSecret,
        refreshToken: null,
        username: twitterUser.data.username,
        profileUrl: twitterUser.data.profile_image_url || null,
        name: twitterUser.data.name,
      });
      
      return twitterAccount;
    } catch (error) {
      console.error('Error handling Twitter callback:', error);
      throw new Error('Failed to complete Twitter authorization');
    }
  },

  /**
   * Post a tweet on behalf of the user
   * @param userId - User ID
   * @param content - Tweet content
   * @param mediaIds - Optional Twitter media IDs
   * @returns Posted tweet data
   */
  async postTweet(userId: number, content: string, mediaIds?: string[]) {
    try {
      // Get the user's Twitter account
      const twitterAccount = await storage.getSocialAccountByPlatform(userId, 'twitter');
      
      if (!twitterAccount) {
        throw new Error('Twitter account not connected');
      }
      
      // Create a client with the user's access tokens
      const userClient = new TwitterApi({
        appKey: process.env.TWITTER_API_KEY!,
        appSecret: process.env.TWITTER_API_SECRET!,
        accessToken: twitterAccount.accessToken,
        accessSecret: twitterAccount.accessTokenSecret!,
      });
      
      // Post the tweet
      // Handle media IDs correctly to match the Twitter API requirements
      let mediaOptions;
      if (mediaIds && mediaIds.length > 0) {
        // Convert to tuple types based on the number of media IDs
        if (mediaIds.length === 1) {
          mediaOptions = { media_ids: [mediaIds[0]] as [string] };
        } else if (mediaIds.length === 2) {
          mediaOptions = { media_ids: [mediaIds[0], mediaIds[1]] as [string, string] };
        } else if (mediaIds.length === 3) {
          mediaOptions = { media_ids: [mediaIds[0], mediaIds[1], mediaIds[2]] as [string, string, string] };
        } else if (mediaIds.length >= 4) {
          mediaOptions = { media_ids: [mediaIds[0], mediaIds[1], mediaIds[2], mediaIds[3]] as [string, string, string, string] };
        }
      }
      
      const tweetData = await userClient.v2.tweet(content, {
        media: mediaOptions
      });
      
      return tweetData;
    } catch (error) {
      console.error('Error posting tweet:', error);
      throw new Error('Failed to post tweet');
    }
  },

  /**
   * Get basic Twitter account stats
   * @param userId - User ID
   * @returns Twitter account stats
   */
  async getAccountStats(userId: number) {
    try {
      // Get the user's Twitter account
      const twitterAccount = await storage.getSocialAccountByPlatform(userId, 'twitter');
      
      if (!twitterAccount) {
        throw new Error('Twitter account not connected');
      }
      
      // Create a client with the user's access tokens
      const userClient = new TwitterApi({
        appKey: process.env.TWITTER_API_KEY!,
        appSecret: process.env.TWITTER_API_SECRET!,
        accessToken: twitterAccount.accessToken,
        accessSecret: twitterAccount.accessTokenSecret!,
      });
      
      // Get follower count and other user data
      const userData = await userClient.v2.user(twitterAccount.accountId, {
        'user.fields': ['public_metrics', 'profile_image_url', 'description']
      });
      
      if (!userData.data) {
        throw new Error('Failed to retrieve Twitter user data');
      }
      
      // Get recent tweets for engagement analysis
      const tweets = await userClient.v2.userTimeline(twitterAccount.accountId, {
        max_results: 10,
        'tweet.fields': ['public_metrics', 'created_at'],
      });
      
      // Calculate average engagement metrics
      const tweetMetrics = tweets.data.data.map(tweet => tweet.public_metrics);
      const avgEngagement = tweetMetrics.length > 0 
        ? {
            likes: tweetMetrics.reduce((sum, metrics) => sum + (metrics?.like_count || 0), 0) / tweetMetrics.length,
            retweets: tweetMetrics.reduce((sum, metrics) => sum + (metrics?.retweet_count || 0), 0) / tweetMetrics.length,
            replies: tweetMetrics.reduce((sum, metrics) => sum + (metrics?.reply_count || 0), 0) / tweetMetrics.length,
          }
        : { likes: 0, retweets: 0, replies: 0 };
      
      // Using the correct field names from our schema
      const username = twitterAccount.username || twitterAccount.accountName;
      
      return {
        id: twitterAccount.id,
        username,
        name: twitterAccount.name || username,
        profileUrl: twitterAccount.profileUrl || null,
        followers: userData.data.public_metrics?.followers_count || 0,
        following: userData.data.public_metrics?.following_count || 0,
        tweets: userData.data.public_metrics?.tweet_count || 0,
        engagement: avgEngagement,
      };
    } catch (error) {
      console.error('Error getting Twitter account stats:', error);
      throw new Error('Failed to get Twitter account stats');
    }
  }
};