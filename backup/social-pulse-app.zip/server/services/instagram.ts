import { storage } from '../storage';
import axios from 'axios';

// Check if the required environment variables are set
const INSTAGRAM_APP_ID = process.env.INSTAGRAM_APP_ID;
const INSTAGRAM_APP_SECRET = process.env.INSTAGRAM_APP_SECRET;

if (!INSTAGRAM_APP_ID || !INSTAGRAM_APP_SECRET) {
  console.warn('Instagram API credentials are missing. Instagram integration will not work properly.');
}

// Instagram Graph API Base URL (through Facebook)
const GRAPH_API_BASE = 'https://graph.instagram.com';
const FB_GRAPH_API_BASE = 'https://graph.facebook.com/v18.0';
// Get host dynamically for redirect URI
const getHost = () => {
  return process.env.HOST || 'https://fef338dc-e049-44e4-a807-4f4800367452-00-2nzpmkm3jlvq.riker.repl.co';
};

export const InstagramService = {
  /**
   * Generate OAuth URL for Instagram authorization
   * @returns Instagram OAuth URL
   */
  async generateAuthLink() {
    try {
      if (!INSTAGRAM_APP_ID) {
        throw new Error('Instagram App ID is not configured');
      }

      const redirectUri = `${getHost()}/auth/instagram/callback`;
      const state = 'state-' + Math.random().toString(36).substring(2, 15);
      
      // Generate the OAuth URL for Instagram Basic Display API
      const authUrl = `https://api.instagram.com/oauth/authorize?` +
        `client_id=${INSTAGRAM_APP_ID}` +
        `&redirect_uri=${encodeURIComponent(redirectUri)}` +
        `&scope=user_profile,user_media` +
        `&response_type=code` +
        `&state=${state}`;

      return {
        authUrl,
        state,
      };
    } catch (error: any) {
      console.error('Error generating Instagram auth link:', error);
      throw new Error(`Failed to generate Instagram authorization link: ${error.message}`);
    }
  },

  /**
   * Complete the OAuth flow with the callback data
   * @param userId - ID of the user connecting their Instagram account
   * @param code - Authorization code from callback
   * @returns Connected Instagram account details
   */
  async handleCallback(userId: number, code: string) {
    try {
      if (!INSTAGRAM_APP_ID || !INSTAGRAM_APP_SECRET) {
        throw new Error('Instagram API credentials are not configured');
      }

      const redirectUri = `${getHost()}/auth/instagram/callback`;
      
      // Exchange the authorization code for an access token
      const tokenResponse = await axios.post('https://api.instagram.com/oauth/access_token', 
        new URLSearchParams({
          client_id: INSTAGRAM_APP_ID,
          client_secret: INSTAGRAM_APP_SECRET,
          grant_type: 'authorization_code',
          redirect_uri: redirectUri,
          code: code
        }),
        {
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
          }
        }
      );
      
      if (!tokenResponse.data.access_token || !tokenResponse.data.user_id) {
        throw new Error('Failed to get access token from Instagram');
      }
      
      const accessToken = tokenResponse.data.access_token;
      const igUserId = tokenResponse.data.user_id;
      
      // Get a long-lived token
      const longLivedTokenResponse = await axios.get(`${FB_GRAPH_API_BASE}/oauth/access_token`, {
        params: {
          grant_type: 'ig_exchange_token',
          client_secret: INSTAGRAM_APP_SECRET,
          access_token: accessToken
        }
      });
      
      if (!longLivedTokenResponse.data.access_token) {
        throw new Error('Failed to get long-lived token from Instagram');
      }
      
      const longLivedToken = longLivedTokenResponse.data.access_token;
      
      // Get user profile
      const userResponse = await axios.get(`${GRAPH_API_BASE}/me`, {
        params: {
          fields: 'id,username,account_type',
          access_token: longLivedToken
        }
      });
      
      if (!userResponse.data.id || !userResponse.data.username) {
        throw new Error('Failed to get user information from Instagram');
      }
      
      // Store the account in the database
      const instagramAccount = await storage.createSocialAccount({
        userId,
        platform: 'instagram',
        accountId: userResponse.data.id,
        accountName: userResponse.data.username,
        accessToken: longLivedToken,
        refreshToken: '', // Instagram doesn't use refresh tokens in the same way
        username: userResponse.data.username,
        profileUrl: null, // We'll need to make a separate call to get this
        name: userResponse.data.username,
      });
      
      // Try to get profile picture if possible (requires additional permissions)
      try {
        const mediaResponse = await axios.get(`${GRAPH_API_BASE}/me/media`, {
          params: {
            fields: 'id,media_type,media_url,thumbnail_url,permalink',
            access_token: longLivedToken,
            limit: 1
          }
        });
        
        if (mediaResponse.data.data && mediaResponse.data.data.length > 0) {
          const media = mediaResponse.data.data[0];
          const profileUrl = media.media_type === 'VIDEO' ? media.thumbnail_url : media.media_url;
          
          if (profileUrl) {
            // Update the account with the profile URL
            await storage.updateSocialAccount(instagramAccount.id, {
              profileUrl
            });
            
            instagramAccount.profileUrl = profileUrl;
          }
        }
      } catch (profileError) {
        console.warn('Could not fetch Instagram profile picture:', profileError);
        // This is non-fatal, so we continue
      }
      
      return instagramAccount;
    } catch (error: any) {
      console.error('Error handling Instagram callback:', error);
      
      // Provide more detailed error message
      if (error.response) {
        const igError = error.response.data.error || {};
        throw new Error(`Instagram authorization failed: ${igError.message || error.message}`);
      }
      
      throw new Error(`Failed to complete Instagram authorization: ${error.message}`);
    }
  },

  /**
   * Get basic Instagram account stats
   * @param userId - User ID
   * @returns Instagram account stats
   */
  async getAccountStats(userId: number) {
    try {
      // Get the user's Instagram account
      const instagramAccount = await storage.getSocialAccountByPlatform(userId, 'instagram');
      
      if (!instagramAccount || !instagramAccount.accessToken) {
        throw new Error('Instagram account not connected or missing access token');
      }
      
      const accessToken = instagramAccount.accessToken;
      
      // Get user profile
      const userResponse = await axios.get(`${GRAPH_API_BASE}/me`, {
        params: {
          fields: 'id,username,media_count',
          access_token: accessToken
        }
      });
      
      // Get user's media
      const mediaResponse = await axios.get(`${GRAPH_API_BASE}/me/media`, {
        params: {
          fields: 'id,media_type,media_url,thumbnail_url,permalink,like_count,comments_count',
          access_token: accessToken,
          limit: 20
        }
      });
      
      const media = mediaResponse.data.data || [];
      let totalLikes = 0;
      let totalComments = 0;
      let totalEngagement = 0;
      
      media.forEach((item: any) => {
        totalLikes += item.like_count || 0;
        totalComments += item.comments_count || 0;
      });
      
      totalEngagement = totalLikes + totalComments;
      
      return {
        id: instagramAccount.id,
        username: instagramAccount.username || instagramAccount.accountName,
        name: instagramAccount.name || instagramAccount.username || instagramAccount.accountName,
        profileUrl: instagramAccount.profileUrl || null,
        followers: 'N/A', // Instagram Basic Display API doesn't provide follower count
        posts: userResponse.data.media_count || media.length,
        engagement: {
          likes: totalLikes,
          comments: totalComments,
          saves: 'N/A', // Not available in the Basic Display API
        },
        reachAverage: 'N/A', // Not available in the Basic Display API
        engagementRate: media.length > 0 ? totalEngagement / media.length : 0,
        mediaCount: media.length,
      };
    } catch (error: any) {
      console.error('Error getting Instagram account stats:', error);
      
      // Provide more detailed error message
      if (error.response) {
        const igError = error.response.data.error || {};
        throw new Error(`Failed to get Instagram account stats: ${igError.message || error.message}`);
      }
      
      throw new Error(`Failed to get Instagram account stats: ${error.message}`);
    }
  },
  
  /**
   * Post content to Instagram (Note: This function is limited due to API restrictions)
   * @param userId - User ID
   * @param caption - Post caption 
   * @param mediaUrl - Media URL (required for Instagram)
   * @returns Object indicating success or limitations
   */
  async postToInstagram(userId: number, caption: string, mediaUrl?: string) {
    try {
      // Get the user's Instagram account
      const instagramAccount = await storage.getSocialAccountByPlatform(userId, 'instagram');
      
      if (!instagramAccount || !instagramAccount.accessToken) {
        throw new Error('Instagram account not connected or missing access token');
      }
      
      // NOTE: Instagram Graph API has strict limitations on content publishing
      // Only business accounts can publish content, and it requires a different
      // approach using the Facebook Graph API with an Instagram Business account
      
      if (!mediaUrl) {
        throw new Error('Instagram posts require media (image or video)');
      }
      
      // Check if we have a business account (which would allow posting)
      const userResponse = await axios.get(`${GRAPH_API_BASE}/me`, {
        params: {
          fields: 'id,username,account_type',
          access_token: instagramAccount.accessToken
        }
      });
      
      if (userResponse.data.account_type !== 'BUSINESS') {
        // Return informative response about limitations
        return {
          success: false,
          id: null,
          message: 'Instagram posting requires a business account connected through Facebook',
          limitations: [
            'Instagram posting is only available for Instagram Business accounts',
            'You need to connect your Instagram account through the Facebook integration',
            'The account must have appropriate permissions set in the Facebook Developer portal'
          ],
          created_time: new Date().toISOString(),
          permalink_url: null,
        };
      }
      
      // Otherwise, this is a theoretical implementation that would work for business accounts
      // through the Facebook Graph API
      return {
        success: false,
        message: 'Instagram posting is not implemented for this account type',
        created_time: new Date().toISOString(),
      };
    } catch (error: any) {
      console.error('Error posting to Instagram:', error);
      
      // Provide more detailed error message
      if (error.response) {
        const igError = error.response.data.error || {};
        throw new Error(`Failed to post to Instagram: ${igError.message || error.message}`);
      }
      
      throw new Error(`Failed to post to Instagram: ${error.message}`);
    }
  }
};