import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertSocialAccountSchema, insertPostSchema } from "@shared/schema";
import session from "express-session";
import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import MemoryStore from "memorystore";
import bcrypt from "bcryptjs";
import Stripe from "stripe";
import { TwitterService } from "./services/twitter";
import { FacebookService } from "./services/facebook";
import { InstagramService } from "./services/instagram";
import { ContentAnalyzer } from "./services/contentAnalyzer";

// Extend session interface to add custom properties
declare module 'express-session' {
  interface SessionData {
    twitterAuth?: {
      oauth_token_secret?: string;
    };
  }
}

// Initialize session store
const SessionStore = MemoryStore(session);

// Initialize Stripe (will use dummy keys if not provided)
const stripeSecretKey = process.env.STRIPE_SECRET_KEY || "sk_test_dummy";
const stripe = new Stripe(stripeSecretKey, {
  apiVersion: "2025-03-31.basil",
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Session setup
  app.use(
    session({
      cookie: { maxAge: 86400000 }, // 24 hours
      store: new SessionStore({
        checkPeriod: 86400000, // prune expired entries every 24h
      }),
      resave: false,
      saveUninitialized: false,
      secret: process.env.SESSION_SECRET || "social-pulse-secret",
    })
  );

  // Passport initialization
  app.use(passport.initialize());
  app.use(passport.session());

  // Passport local strategy
  passport.use(
    new LocalStrategy(
      { usernameField: "email" },
      async (email, password, done) => {
        try {
          const user = await storage.getUserByEmail(email);
          if (!user) {
            return done(null, false, { message: "Incorrect email or password" });
          }

          // Check if password is available (might be null for OAuth users)
          if (!user.password) {
            return done(null, false, { message: "Incorrect email or password" });
          }
          
          const isMatch = await bcrypt.compare(password, user.password);
          if (!isMatch) {
            return done(null, false, { message: "Incorrect email or password" });
          }

          return done(null, user);
        } catch (error) {
          return done(error);
        }
      }
    )
  );

  passport.serializeUser((user: any, done) => {
    done(null, user.id);
  });

  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (error) {
      done(error);
    }
  });

  // Authentication middleware
  const isAuthenticated = (req: Request, res: Response, next: any) => {
    if (req.isAuthenticated()) {
      return next();
    }
    res.status(401).json({ message: "Unauthorized" });
  };

  // Authentication routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const validatedData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(validatedData.email);
      if (existingUser) {
        return res.status(400).json({ message: "Email already in use" });
      }

      // Hash password if provided
      let hashedPassword = null;
      if (validatedData.password && typeof validatedData.password === 'string') {
        const salt = await bcrypt.genSalt(10);
        hashedPassword = await bcrypt.hash(validatedData.password, salt);
      }

      // Create user with hashed password if available
      const user = await storage.createUser({
        ...validatedData,
        password: hashedPassword,
      });

      // Remove password from response
      const { password, ...userWithoutPassword } = user;
      
      res.status(201).json(userWithoutPassword);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.post("/api/auth/login", (req, res, next) => {
    passport.authenticate("local", (err: any, user: any, info: any) => {
      if (err) {
        return next(err);
      }
      if (!user) {
        return res.status(401).json({ message: info.message });
      }
      req.logIn(user, (err) => {
        if (err) {
          return next(err);
        }
        const { password, ...userWithoutPassword } = user;
        return res.json(userWithoutPassword);
      });
    })(req, res, next);
  });

  app.post("/api/auth/logout", (req, res) => {
    req.logout((err) => {
      if (err) {
        return res.status(500).json({ message: "Logout failed" });
      }
      res.json({ message: "Logged out successfully" });
    });
  });
  
  // Google OAuth callback handler
  app.post("/api/auth/google-callback", async (req, res) => {
    try {
      const { email, fullName, photoURL, googleId } = req.body;
      
      if (!email || !googleId) {
        return res.status(400).json({ message: "Email and Google ID are required" });
      }
      
      // Create or get user from database
      const user = await storage.createGoogleUser({
        email,
        fullName,
        photoURL,
        googleId
      });
      
      // Log in the user
      req.login(user, (err) => {
        if (err) {
          return res.status(500).json({ message: "Login failed after OAuth" });
        }
        
        // Remove password from response
        const { password, ...userWithoutPassword } = user;
        return res.status(200).json(userWithoutPassword);
      });
    } catch (error: any) {
      console.error("Google OAuth callback error:", error);
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/auth/user", isAuthenticated, (req, res) => {
    const { password, ...userWithoutPassword } = req.user as any;
    res.json(userWithoutPassword);
  });

  // User routes
  app.put("/api/users/:id", isAuthenticated, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const user = req.user as any;
      
      // Ensure user can only update their own account
      if (user.id !== userId) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const updatedUser = await storage.updateUser(userId, req.body);
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const { password, ...userWithoutPassword } = updatedUser;
      res.json(userWithoutPassword);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Social account routes
  app.get("/api/social-accounts", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const accounts = await storage.getSocialAccounts(user.id);
      res.json(accounts);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/social-accounts", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const validatedData = insertSocialAccountSchema.parse({
        ...req.body,
        userId: user.id
      });
      
      const account = await storage.createSocialAccount(validatedData);
      res.status(201).json(account);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.delete("/api/social-accounts/:id", isAuthenticated, async (req, res) => {
    try {
      const accountId = parseInt(req.params.id);
      const success = await storage.deleteSocialAccount(accountId);
      
      if (!success) {
        return res.status(404).json({ message: "Social account not found" });
      }
      
      res.json({ message: "Social account deleted successfully" });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Post routes
  app.get("/api/posts", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const posts = await storage.getPosts(user.id);
      res.json(posts);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/posts/scheduled", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const scheduledPosts = await storage.getScheduledPosts(user.id);
      res.json(scheduledPosts);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/posts", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const validatedData = insertPostSchema.parse({
        ...req.body,
        userId: user.id
      });
      
      const post = await storage.createPost(validatedData);
      res.status(201).json(post);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.put("/api/posts/:id", isAuthenticated, async (req, res) => {
    try {
      const postId = parseInt(req.params.id);
      const updatedPost = await storage.updatePost(postId, req.body);
      
      if (!updatedPost) {
        return res.status(404).json({ message: "Post not found" });
      }
      
      res.json(updatedPost);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.delete("/api/posts/:id", isAuthenticated, async (req, res) => {
    try {
      const postId = parseInt(req.params.id);
      const success = await storage.deletePost(postId);
      
      if (!success) {
        return res.status(404).json({ message: "Post not found" });
      }
      
      res.json({ message: "Post deleted successfully" });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Subscription plan routes
  app.get("/api/subscription-plans", async (req, res) => {
    try {
      const plans = await storage.getSubscriptionPlans();
      res.json(plans);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Stripe payment route for one-time payments
  app.post("/api/create-payment-intent", isAuthenticated, async (req, res) => {
    try {
      const { amount, planId, metadata } = req.body;
      const user = req.user as any;
      
      if (!amount) {
        return res.status(400).json({ message: "Amount is required" });
      }

      // Create a PaymentIntent with the order amount and currency
      const paymentIntent = await stripe.paymentIntents.create({
        amount: Math.round(amount), // Amount in cents
        currency: "usd",
        metadata: {
          planId: planId?.toString(),
          userId: user.id.toString(),
          ...metadata
        },
      });

      res.json({ clientSecret: paymentIntent.client_secret });
    } catch (error: any) {
      console.error("Error creating payment intent:", error);
      res.status(500).json({ message: "Error creating payment intent: " + error.message });
    }
  });

  // Endpoint for creating or getting a subscription with a custom price
  app.post("/api/get-or-create-subscription", isAuthenticated, async (req, res) => {
    const user = req.user as any;
    const { planId, priceAmount, interval, planName } = req.body;
    
    if (!planId || !priceAmount) {
      return res.status(400).json({ message: "Plan ID and price amount are required" });
    }
    
    try {
      // Check if user already has a subscription
      if (user.stripeSubscriptionId) {
        try {
          const subscription = await stripe.subscriptions.retrieve(user.stripeSubscriptionId, {
            expand: ['latest_invoice.payment_intent']
          });
          
          // If subscription is active, return it
          if (subscription.status === 'active') {
            return res.json({
              subscriptionId: subscription.id,
              clientSecret: null, // No need for client secret if already active
            });
          }
          
          // Otherwise, continue to create a new one
        } catch (err) {
          // If subscription doesn't exist anymore or is invalid, continue to create a new one
          console.log("Existing subscription not found, creating new one");
        }
      }
      
      // Create or get Stripe customer
      let customerId = user.stripeCustomerId;
      
      if (!customerId) {
        if (!user.email) {
          return res.status(400).json({ message: "User email is required" });
        }

        const customer = await stripe.customers.create({
          email: user.email,
          name: user.fullName || user.username,
        });
        
        customerId = customer.id;
        
        // Update user with Stripe customer ID
        await storage.updateStripeCustomerId(user.id, customerId);
      }
      
      // Create a product for this plan
      const product = await stripe.products.create({
        name: planName || `${interval === 'yearly' ? 'Yearly' : 'Monthly'} Plan`,
        description: `${interval === 'yearly' ? 'Yearly' : 'Monthly'} subscription plan`,
      });
      
      // Create a price for the subscription
      const price = await stripe.prices.create({
        product: product.id,
        unit_amount: priceAmount,
        currency: 'usd',
        recurring: {
          interval: interval === 'yearly' ? 'year' : 'month',
        },
      });
      
      // Create subscription with the price
      const subscription = await stripe.subscriptions.create({
        customer: customerId,
        items: [{ price: price.id }],
        payment_behavior: 'default_incomplete',
        expand: ['latest_invoice.payment_intent'],
        metadata: {
          userId: user.id.toString(),
          planName: planName ? planName.toLowerCase() : 'custom',
        }
      });
      
      // Update user with subscription ID
      await storage.updateUserStripeInfo(user.id, {
        stripeCustomerId: customerId,
        stripeSubscriptionId: subscription.id
      });
      
      // Return the client secret for payment
      const invoice = subscription.latest_invoice as any;
      const paymentIntent = invoice?.payment_intent;
      
      res.json({
        subscriptionId: subscription.id,
        clientSecret: paymentIntent?.client_secret || null,
      });
    } catch (error: any) {
      console.error("Error creating subscription:", error);
      res.status(500).json({ message: error.message });
    }
  });
  
  // Original subscription creation endpoint
  app.post("/api/create-subscription", isAuthenticated, async (req, res) => {
    const user = req.user as any;
    const { planId } = req.body;
    
    if (!planId) {
      return res.status(400).json({ message: "Plan ID is required" });
    }
    
    try {
      const plan = await storage.getSubscriptionPlan(parseInt(planId));
      
      if (!plan) {
        return res.status(404).json({ message: "Subscription plan not found" });
      }
      
      let customer;
      
      // Check if user already has a Stripe customer ID
      if (user.stripeCustomerId) {
        customer = { id: user.stripeCustomerId };
      } else {
        // Create a new customer
        customer = await stripe.customers.create({
          email: user.email,
          name: user.fullName || user.username,
        });
        
        // Update user with Stripe customer ID
        await storage.updateStripeCustomerId(user.id, customer.id);
      }
      
      // First, create a product
      const product = await stripe.products.create({
        name: plan.name,
        description: plan.description,
      });
      
      // Then create a price for that product
      const price = await stripe.prices.create({
        product: product.id,
        currency: 'usd',
        unit_amount: plan.price,
        recurring: {
          interval: plan.interval === 'yearly' ? 'year' : 'month',
        },
      });
      
      // Create subscription with price
      const subscription = await stripe.subscriptions.create({
        customer: customer.id,
        items: [{ price: price.id }],
        payment_behavior: 'default_incomplete',
        expand: ['latest_invoice.payment_intent'],
        metadata: {
          userId: user.id.toString(),
          planName: plan.name.toLowerCase(),
        }
      });
      
      // Update user with subscription ID and plan
      await storage.updateUser(user.id, {
        stripeSubscriptionId: subscription.id,
        currentPlan: plan.name.toLowerCase(),
      });
      
      res.json({
        subscriptionId: subscription.id,
        clientSecret: (subscription.latest_invoice as any)?.payment_intent?.client_secret,
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Stripe webhook handler
  app.post('/api/stripe-webhook', async (req, res) => {
    try {
      const sig = req.headers['stripe-signature'];
      const endpointSecret = process.env.STRIPE_WEBHOOK_SECRET;
      
      if (!sig || !endpointSecret) {
        return res.status(400).json({ message: "Missing stripe signature or webhook secret" });
      }

      // Verify webhook signature
      let event;
      
      try {
        event = stripe.webhooks.constructEvent(req.body, sig, endpointSecret);
      } catch (err: any) {
        console.error(`Webhook Error: ${err.message}`);
        return res.status(400).json({ message: `Webhook Error: ${err.message}` });
      }
      
      // Handle the event
      switch (event.type) {
        case 'invoice.payment_succeeded':
          const invoice = event.data.object as any;
          if (invoice.subscription) {
            // Update user's subscription status
            const subscriptionId = typeof invoice.subscription === 'string' 
              ? invoice.subscription 
              : invoice.subscription.id;
              
            const subscription = await stripe.subscriptions.retrieve(subscriptionId);
            
            if (subscription && subscription.metadata && subscription.metadata.userId) {
              const userId = parseInt(subscription.metadata.userId);
              const planName = subscription.metadata.planName || 'business';
              
              // Update user's current plan
              await storage.updateUser(userId, { 
                currentPlan: planName.toLowerCase()
              });
            }
          }
          break;
          
        case 'customer.subscription.deleted':
          const subscription = event.data.object as any;
          if (subscription.metadata && subscription.metadata.userId) {
            const userId = parseInt(subscription.metadata.userId);
            
            // Reset user's plan to free
            await storage.updateUser(userId, { 
              currentPlan: 'free',
              stripeSubscriptionId: null
            });
          }
          break;
          
        default:
          console.log(`Unhandled event type ${event.type}`);
      }

      res.json({ received: true });
    } catch (error: any) {
      console.error("Error processing Stripe webhook:", error);
      res.status(400).json({ message: `Webhook Error: ${error.message}` });
    }
  });

  // User stats routes
  app.get("/api/user-stats", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const stats = await storage.getUserStats(user.id);
      res.json(stats);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Twitter OAuth Routes
  app.get("/api/twitter/auth", isAuthenticated, async (req, res) => {
    try {
      // Generate Twitter authentication URL
      const authData = await TwitterService.generateAuthLink();
      
      console.log("Twitter OAuth initialized:", {
        oauth_token: authData.oauth_token,
        oauth_token_secret: authData.oauth_token_secret ? "EXISTS" : "MISSING",
        callbackUrl: process.env.TWITTER_CALLBACK_URL
      });
      
      // Return the authentication URL and both tokens
      // Client will store oauth_token_secret in localStorage
      res.json({ 
        authUrl: authData.authUrl,
        oauth_token: authData.oauth_token,
        oauth_token_secret: authData.oauth_token_secret
      });
    } catch (error: any) {
      console.error("Twitter auth error:", error);
      
      // Provide more specific error messages for frontend display
      if (error.message && error.message.includes('API authentication failed')) {
        return res.status(401).json({ 
          message: "API authentication failed. Twitter API keys may be invalid or expired." 
        });
      } else if (error.message && error.message.includes('callback URL')) {
        return res.status(400).json({ 
          message: "Invalid Twitter callback URL configuration."
        });
      } else if (!process.env.TWITTER_API_KEY || !process.env.TWITTER_API_SECRET) {
        return res.status(500).json({ 
          message: "Twitter API credentials are missing."
        });
      }
      
      res.status(500).json({ 
        message: "Error initiating Twitter authentication", 
        error: error.message || 'Failed to generate Twitter authorization link'
      });
    }
  });
  
  // Facebook OAuth Routes
  app.get("/api/facebook/auth", isAuthenticated, async (req, res) => {
    try {
      // Check if Facebook API credentials are configured
      if (!process.env.FACEBOOK_APP_ID || !process.env.FACEBOOK_APP_SECRET) {
        return res.status(503).json({ 
          message: "Facebook API credentials are not configured", 
          error: "CREDENTIALS_MISSING",
          details: "Please add FACEBOOK_APP_ID and FACEBOOK_APP_SECRET to environment variables"
        });
      }
      
      // Generate Facebook authentication URL
      const authData = await FacebookService.generateAuthLink();
      
      res.json({
        authUrl: authData.authUrl,
        state: authData.state
      });
    } catch (error: any) {
      console.error("Facebook auth error:", error);
      res.status(500).json({ 
        message: "Error initiating Facebook authentication", 
        error: error.message,
        errorType: "FACEBOOK_AUTH_ERROR"
      });
    }
  });
  
  app.post("/api/facebook/callback", isAuthenticated, async (req, res) => {
    try {
      const { code } = req.body;
      const user = req.user as any;
      
      if (!code) {
        return res.status(400).json({ message: "Authorization code is required" });
      }
      
      // Check if Facebook API credentials are configured
      if (!process.env.FACEBOOK_APP_ID || !process.env.FACEBOOK_APP_SECRET) {
        return res.status(503).json({ 
          message: "Facebook API credentials are not configured", 
          error: "CREDENTIALS_MISSING",
          details: "Please add FACEBOOK_APP_ID and FACEBOOK_APP_SECRET to environment variables"
        });
      }
      
      // Complete the OAuth flow
      const facebookAccount = await FacebookService.handleCallback(user.id, code);
      
      res.json(facebookAccount);
    } catch (error: any) {
      console.error("Facebook callback error:", error);
      
      let statusCode = 500;
      let errorType = "FACEBOOK_AUTH_ERROR";
      
      // Check for specific error types
      if (error.message.includes("API credentials are not configured")) {
        statusCode = 503;
        errorType = "CREDENTIALS_MISSING";
      } else if (error.message.includes("code is invalid")) {
        statusCode = 400;
        errorType = "INVALID_CODE";
      }
      
      res.status(statusCode).json({ 
        message: "Error completing Facebook authentication", 
        error: error.message,
        errorType: errorType
      });
    }
  });
  
  app.post("/api/facebook/post", isAuthenticated, async (req, res) => {
    try {
      const { content, mediaUrl } = req.body;
      const user = req.user as any;
      
      if (!content) {
        return res.status(400).json({ message: "Content is required" });
      }
      
      // Get the user's Facebook account to check if connected
      const facebookAccount = await storage.getSocialAccountByPlatform(user.id, 'facebook');
      
      if (!facebookAccount || !facebookAccount.accessToken) {
        return res.status(403).json({ 
          message: "Facebook account not connected", 
          errorType: "ACCOUNT_NOT_CONNECTED"
        });
      }
      
      // Post to Facebook
      const postData = await FacebookService.postToFacebook(user.id, content, mediaUrl);
      
      res.json({
        success: true,
        post: postData
      });
    } catch (error: any) {
      console.error("Facebook post error:", error);
      
      let statusCode = 500;
      let errorType = "FACEBOOK_POST_ERROR";
      
      // Handle different types of errors
      if (error.message.includes("not connected")) {
        statusCode = 403;
        errorType = "ACCOUNT_NOT_CONNECTED";
      } else if (error.message.includes("API credentials")) {
        statusCode = 503;
        errorType = "CREDENTIALS_MISSING";
      } else if (error.message.includes("token is invalid")) {
        statusCode = 401;
        errorType = "TOKEN_INVALID";
      }
      
      res.status(statusCode).json({ 
        message: "Error posting to Facebook", 
        error: error.message,
        errorType: errorType
      });
    }
  });
  
  app.get("/api/facebook/stats", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      
      // Get the user's Facebook account to check if connected
      const facebookAccount = await storage.getSocialAccountByPlatform(user.id, 'facebook');
      
      if (!facebookAccount || !facebookAccount.accessToken) {
        return res.status(403).json({ 
          message: "Facebook account not connected", 
          errorType: "ACCOUNT_NOT_CONNECTED"
        });
      }
      
      // Get Facebook account stats
      const stats = await FacebookService.getAccountStats(user.id);
      
      res.json(stats);
    } catch (error: any) {
      console.error("Facebook stats error:", error);
      
      let statusCode = 500;
      let errorType = "FACEBOOK_STATS_ERROR";
      
      // Handle different types of errors
      if (error.message.includes("not connected")) {
        statusCode = 403;
        errorType = "ACCOUNT_NOT_CONNECTED";
      } else if (error.message.includes("API credentials")) {
        statusCode = 503;
        errorType = "CREDENTIALS_MISSING";
      } else if (error.message.includes("token is invalid")) {
        statusCode = 401;
        errorType = "TOKEN_INVALID";
      }
      
      res.status(statusCode).json({ 
        message: "Error fetching Facebook stats", 
        error: error.message,
        errorType: errorType
      });
    }
  });
  
  // Instagram OAuth Routes
  app.get("/api/instagram/auth", isAuthenticated, async (req, res) => {
    try {
      // Check if Instagram API credentials are configured
      if (!process.env.INSTAGRAM_APP_ID || !process.env.INSTAGRAM_APP_SECRET) {
        return res.status(503).json({ 
          message: "Instagram API credentials are not configured", 
          error: "CREDENTIALS_MISSING",
          details: "Please add INSTAGRAM_APP_ID and INSTAGRAM_APP_SECRET to environment variables"
        });
      }
      
      // Generate Instagram authentication URL
      const authData = await InstagramService.generateAuthLink();
      
      res.json({
        authUrl: authData.authUrl,
        state: authData.state
      });
    } catch (error: any) {
      console.error("Instagram auth error:", error);
      res.status(500).json({ 
        message: "Error initiating Instagram authentication", 
        error: error.message,
        errorType: "INSTAGRAM_AUTH_ERROR"
      });
    }
  });
  
  app.post("/api/instagram/callback", isAuthenticated, async (req, res) => {
    try {
      const { code } = req.body;
      const user = req.user as any;
      
      if (!code) {
        return res.status(400).json({ message: "Authorization code is required" });
      }
      
      // Check if Instagram API credentials are configured
      if (!process.env.INSTAGRAM_APP_ID || !process.env.INSTAGRAM_APP_SECRET) {
        return res.status(503).json({ 
          message: "Instagram API credentials are not configured", 
          error: "CREDENTIALS_MISSING",
          details: "Please add INSTAGRAM_APP_ID and INSTAGRAM_APP_SECRET to environment variables"
        });
      }
      
      // Complete the OAuth flow
      const instagramAccount = await InstagramService.handleCallback(user.id, code);
      
      res.json(instagramAccount);
    } catch (error: any) {
      console.error("Instagram callback error:", error);
      
      let statusCode = 500;
      let errorType = "INSTAGRAM_AUTH_ERROR";
      
      // Check for specific error types
      if (error.message.includes("API credentials are not configured")) {
        statusCode = 503;
        errorType = "CREDENTIALS_MISSING";
      } else if (error.message.includes("code is invalid")) {
        statusCode = 400;
        errorType = "INVALID_CODE";
      }
      
      res.status(statusCode).json({ 
        message: "Error completing Instagram authentication", 
        error: error.message,
        errorType: errorType
      });
    }
  });
  
  // Instagram post endpoint
  app.post("/api/instagram/post", isAuthenticated, async (req, res) => {
    try {
      const { content, mediaUrl } = req.body;
      const user = req.user as any;
      
      if (!content) {
        return res.status(400).json({ message: "Content is required" });
      }
      
      if (!mediaUrl) {
        return res.status(400).json({ 
          message: "Media URL is required for Instagram posts", 
          errorType: "MEDIA_REQUIRED"
        });
      }
      
      // Get the user's Instagram account to check if connected
      const instagramAccount = await storage.getSocialAccountByPlatform(user.id, 'instagram');
      
      if (!instagramAccount || !instagramAccount.accessToken) {
        return res.status(403).json({ 
          message: "Instagram account not connected", 
          errorType: "ACCOUNT_NOT_CONNECTED"
        });
      }
      
      // Post to Instagram
      const result = await InstagramService.postToInstagram(user.id, content, mediaUrl);
      
      // The Instagram service might return a limitations object if posting isn't available
      if (result && !result.success) {
        return res.status(422).json({
          message: result.message || "Instagram posting limitations",
          limitations: result.limitations,
          errorType: "INSTAGRAM_LIMITATIONS"
        });
      }
      
      res.json({
        success: true,
        post: result
      });
    } catch (error: any) {
      console.error("Instagram post error:", error);
      
      let statusCode = 500;
      let errorType = "INSTAGRAM_POST_ERROR";
      
      // Handle different types of errors
      if (error.message.includes("not connected")) {
        statusCode = 403;
        errorType = "ACCOUNT_NOT_CONNECTED";
      } else if (error.message.includes("API credentials")) {
        statusCode = 503;
        errorType = "CREDENTIALS_MISSING";
      } else if (error.message.includes("token is invalid")) {
        statusCode = 401;
        errorType = "TOKEN_INVALID";
      } else if (error.message.includes("require media")) {
        statusCode = 400;
        errorType = "MEDIA_REQUIRED";
      }
      
      res.status(statusCode).json({ 
        message: "Error posting to Instagram", 
        error: error.message,
        errorType: errorType
      });
    }
  });
  
  app.get("/api/instagram/stats", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      
      // Get the user's Instagram account to check if connected
      const instagramAccount = await storage.getSocialAccountByPlatform(user.id, 'instagram');
      
      if (!instagramAccount || !instagramAccount.accessToken) {
        return res.status(403).json({ 
          message: "Instagram account not connected", 
          errorType: "ACCOUNT_NOT_CONNECTED"
        });
      }
      
      // Get Instagram account stats
      const stats = await InstagramService.getAccountStats(user.id);
      
      res.json(stats);
    } catch (error: any) {
      console.error("Instagram stats error:", error);
      
      let statusCode = 500;
      let errorType = "INSTAGRAM_STATS_ERROR";
      
      // Handle different types of errors
      if (error.message.includes("not connected")) {
        statusCode = 403;
        errorType = "ACCOUNT_NOT_CONNECTED";
      } else if (error.message.includes("API credentials")) {
        statusCode = 503;
        errorType = "CREDENTIALS_MISSING";
      } else if (error.message.includes("token is invalid")) {
        statusCode = 401;
        errorType = "TOKEN_INVALID";
      }
      
      res.status(statusCode).json({ 
        message: "Error fetching Instagram stats", 
        error: error.message,
        errorType: errorType
      });
    }
  });

  app.post("/api/twitter/callback", isAuthenticated, async (req, res) => {
    try {
      const { oauth_token, oauth_verifier, oauth_token_secret } = req.body;
      const user = req.user as any;
      
      console.log("Twitter callback received:", { 
        oauth_token: oauth_token ? "EXISTS" : "MISSING", 
        oauth_verifier: oauth_verifier ? "EXISTS" : "MISSING",
        oauth_token_secret: oauth_token_secret ? "EXISTS" : "MISSING"
      });
      
      if (!oauth_token || !oauth_verifier || !oauth_token_secret) {
        console.error("Missing required OAuth parameters");
        return res.status(400).json({ message: "Missing required OAuth parameters" });
      }
      
      // Complete the OAuth flow
      const twitterAccount = await TwitterService.handleCallback(
        user.id,
        oauth_token,
        oauth_verifier,
        oauth_token_secret
      );
      
      console.log("Twitter account connected successfully:", {
        accountId: twitterAccount.accountId,
        username: twitterAccount.username
      });
      
      res.json(twitterAccount);
    } catch (error: any) {
      console.error("Twitter callback error:", error);
      
      // Provide specific error messages for frontend display
      if (error.message && error.message.includes('API authentication failed')) {
        return res.status(401).json({ 
          message: "Twitter API authentication failed. Please reconnect your account."
        });
      } else if (error.message && error.message.includes('token')) {
        return res.status(400).json({ 
          message: "Invalid or expired Twitter authentication tokens. Please try connecting again."
        });
      }
      
      res.status(500).json({ 
        message: "Error completing Twitter authentication", 
        error: error.message || 'Unknown error during Twitter authentication'
      });
    }
  });

  app.post("/api/twitter/post", isAuthenticated, async (req, res) => {
    try {
      const { content, mediaIds } = req.body;
      const user = req.user as any;
      
      if (!content) {
        return res.status(400).json({ message: "Tweet content is required" });
      }
      
      // Post the tweet
      const tweetData = await TwitterService.postTweet(user.id, content, mediaIds);
      
      res.json({ success: true, tweet: tweetData });
    } catch (error: any) {
      console.error("Twitter post error:", error);
      res.status(500).json({ message: "Error posting tweet", error: error.message });
    }
  });

  app.get("/api/twitter/stats", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      
      // Get Twitter account stats
      const stats = await TwitterService.getAccountStats(user.id);
      
      res.json(stats);
    } catch (error: any) {
      console.error("Twitter stats error:", error);
      res.status(500).json({ message: "Error fetching Twitter stats", error: error.message });
    }
  });

  // Content Analyzer routes
  app.post("/api/content/analyze", isAuthenticated, async (req, res) => {
    try {
      const { content, platform, language, audience, purpose } = req.body;
      
      if (!content) {
        return res.status(400).json({ message: "Content is required" });
      }
      
      const analysis = await ContentAnalyzer.analyzeContent(content, {
        platform,
        language,
        audience,
        purpose
      });
      
      res.json(analysis);
    } catch (error: any) {
      console.error("Content analysis error:", error);
      res.status(500).json({ message: "Error analyzing content", error: error.message });
    }
  });

  app.post("/api/content/suggest", isAuthenticated, async (req, res) => {
    try {
      const { content, analysis, platform, audience } = req.body;
      
      if (!content || !analysis) {
        return res.status(400).json({ message: "Content and analysis are required" });
      }
      
      const suggestions = await ContentAnalyzer.getSuggestions(content, analysis, {
        platform,
        audience
      });
      
      res.json(suggestions);
    } catch (error: any) {
      console.error("Content suggestion error:", error);
      res.status(500).json({ message: "Error generating content suggestions", error: error.message });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
