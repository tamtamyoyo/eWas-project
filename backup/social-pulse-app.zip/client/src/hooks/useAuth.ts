import { useEffect, useState } from "react";
import { useQuery, useQueryClient, useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useTranslation } from "react-i18next";
import { User } from "@shared/schema";

export const useAuth = () => {
  const { t } = useTranslation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [initialLoadComplete, setInitialLoadComplete] = useState(false);

  // Query for fetching the current user
  const { 
    data: user, 
    isLoading,
    refetch: refetchUser,
    isError
  } = useQuery<User | null>({
    queryKey: ['/api/auth/user'],
    queryFn: async () => {
      try {
        const res = await fetch('/api/auth/user', {
          credentials: 'include'
        });
        
        if (res.status === 401) {
          return null;
        }
        
        if (!res.ok) {
          throw new Error(`Error fetching user: ${res.statusText}`);
        }
        
        return await res.json();
      } catch (error) {
        console.error("Error fetching user:", error);
        return null;
      }
    },
    retry: false,
    staleTime: 0
  });

  // Logout mutation
  const logoutMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", "/api/auth/logout", {});
    },
    onSuccess: () => {
      queryClient.clear();
      toast({
        title: t('auth.logoutSuccess'),
        description: t('auth.logoutSuccessMessage'),
      });
      window.location.href = "/login";
    },
    onError: (error: any) => {
      toast({
        title: t('auth.logoutError'),
        description: error.message,
        variant: "destructive",
      });
    }
  });

  // Function to handle logout
  const logout = () => {
    logoutMutation.mutate();
  };

  // Set initial load complete after first query
  useEffect(() => {
    if (!isLoading) {
      setInitialLoadComplete(true);
    }
  }, [isLoading]);

  return {
    user,
    loading: isLoading && !initialLoadComplete,
    isAuthenticated: !!user,
    logout,
    refetchUser,
    authError: isError
  };
};
