import { useState } from "react";
import { useTranslation } from "react-i18next";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { type SocialAccount } from "@shared/schema";
import { useAuth } from "@/hooks/useAuth";
import TwitterConnectButton from "@/components/connect/TwitterConnectButton";
import FacebookConnectButton from "@/components/connect/FacebookConnectButton";
import InstagramConnectButton from "@/components/connect/InstagramConnectButton";

// Social platform configuration for display
const platforms = [
  {
    id: "facebook",
    name: "Facebook",
    icon: "fa-facebook-f",
    color: "#4267B2",
    description: "Connect your Facebook page to schedule posts and view analytics"
  },
  {
    id: "instagram",
    name: "Instagram",
    icon: "fa-instagram",
    color: "#E1306C",
    description: "Connect your Instagram account to schedule posts and track engagement"
  },
  {
    id: "twitter",
    name: "Twitter",
    icon: "fa-twitter",
    color: "#1DA1F2",
    description: "Connect your Twitter profile to schedule tweets and track performance"
  },
  {
    id: "linkedin",
    name: "LinkedIn",
    icon: "fa-linkedin-in",
    color: "#0077B5",
    description: "Connect your LinkedIn page to share professional updates"
  },
  {
    id: "snapchat",
    name: "Snapchat",
    icon: "fa-snapchat",
    color: "#FFFC00",
    description: "Connect your Snapchat account to manage and schedule snaps"
  }
];

export default function Connect() {
  const { t } = useTranslation();
  const { toast } = useToast();
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [selectedPlatform, setSelectedPlatform] = useState<string | null>(null);
  const [connectForm, setConnectForm] = useState({
    accountName: "",
    accessToken: "oauth-access-token-placeholder", // In real app, this would come from OAuth
    refreshToken: "oauth-refresh-token-placeholder" // In real app, this would come from OAuth
  });

  // Fetch connected accounts
  const { data: connectedAccounts, isLoading } = useQuery<SocialAccount[]>({
    queryKey: ['/api/social-accounts'],
  });

  // Connect social account mutation
  const connectMutation = useMutation({
    mutationFn: async (accountData: any) => {
      const response = await apiRequest("POST", "/api/social-accounts", accountData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/social-accounts'] });
      toast({
        title: t('connect.successTitle'),
        description: t('connect.successMessage'),
      });
      setSelectedPlatform(null);
      setConnectForm({
        accountName: "",
        accessToken: "oauth-access-token-placeholder",
        refreshToken: "oauth-refresh-token-placeholder"
      });
    },
    onError: (error: any) => {
      toast({
        title: t('connect.errorTitle'),
        description: error.message,
        variant: "destructive",
      });
    }
  });

  // Disconnect social account mutation
  const disconnectMutation = useMutation({
    mutationFn: async (accountId: number) => {
      await apiRequest("DELETE", `/api/social-accounts/${accountId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/social-accounts'] });
      toast({
        title: t('connect.disconnectSuccessTitle'),
        description: t('connect.disconnectSuccessMessage'),
      });
    },
    onError: (error: any) => {
      toast({
        title: t('connect.disconnectErrorTitle'),
        description: error.message,
        variant: "destructive",
      });
    }
  });

  const handleConnect = (platform: string) => {
    setSelectedPlatform(platform);
  };

  const handleSubmitConnect = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPlatform) return;
    
    // In a real implementation, this would be handled by OAuth
    // Here we're just simulating the connection process
    connectMutation.mutate({
      platform: selectedPlatform,
      accountId: `${selectedPlatform}-${Date.now()}`, // Mock ID
      accountName: connectForm.accountName,
      accessToken: connectForm.accessToken,
      refreshToken: connectForm.refreshToken,
      isConnected: true
    });
  };

  const handleDisconnect = (accountId: number) => {
    if (confirm(t('connect.confirmDisconnect'))) {
      disconnectMutation.mutate(accountId);
    }
  };

  // Find if a platform is already connected
  const isPlatformConnected = (platformId: string) => {
    return connectedAccounts?.some(account => account.platform === platformId);
  };

  // Get connected account for a platform
  const getConnectedAccount = (platformId: string) => {
    return connectedAccounts?.find(account => account.platform === platformId);
  };

  return (
    <>
      <div className="mb-6">
        <h1 className="text-2xl font-bold">{t('connect.title')}</h1>
        <p className="text-neutral-500">{t('connect.subtitle')}</p>
      </div>

      {/* Connect Form Modal */}
      {selectedPlatform && (
        <Card className="mb-6 border-primary">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <div
                  className="w-10 h-10 rounded-full flex items-center justify-center text-white"
                  style={{
                    backgroundColor: platforms.find(p => p.id === selectedPlatform)?.color
                  }}
                >
                  <i className={`fa-brands ${platforms.find(p => p.id === selectedPlatform)?.icon}`}></i>
                </div>
                <h3 className="font-semibold">{t('connect.connectTo', { platform: platforms.find(p => p.id === selectedPlatform)?.name })}</h3>
              </div>
              <Button variant="ghost" size="sm" onClick={() => setSelectedPlatform(null)}>
                <i className="fa-solid fa-times"></i>
              </Button>
            </div>

            <form onSubmit={handleSubmitConnect} className="space-y-4">
              <div>
                <Label htmlFor="accountName">{t('connect.accountName')}</Label>
                <Input
                  id="accountName"
                  value={connectForm.accountName}
                  onChange={(e) => setConnectForm({ ...connectForm, accountName: e.target.value })}
                  placeholder="@yourusername"
                  required
                />
                <p className="text-xs text-neutral-500 mt-1">{t('connect.accountNameDesc')}</p>
              </div>

              <div className="pt-2">
                <Button type="submit" disabled={connectMutation.isPending}>
                  {connectMutation.isPending ? (
                    <div className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent"></div>
                  ) : (
                    <>
                      <i className="fa-solid fa-link mr-2"></i>
                      {t('connect.connectButton')}
                    </>
                  )}
                </Button>
                <Button 
                  type="button" 
                  variant="ghost" 
                  onClick={() => setSelectedPlatform(null)}
                  className="ml-2"
                >
                  {t('common.cancel')}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      {/* Connected Accounts */}
      <Card className="mb-6">
        <CardContent className="p-6">
          <h3 className="font-semibold mb-6">{t('connect.connectedAccounts')}</h3>

          {isLoading ? (
            <div className="flex justify-center py-8">
              <div className="h-6 w-6 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
            </div>
          ) : (
            <div className="space-y-4">
              {platforms.map((platform) => {
                const isConnected = isPlatformConnected(platform.id);
                const connectedAccount = getConnectedAccount(platform.id);

                return (
                  <div key={platform.id} className="flex items-center justify-between p-4 border border-neutral-100 rounded-lg hover:border-neutral-300 transition-all">
                    <div className="flex items-center">
                      <div
                        className="w-10 h-10 rounded-full flex items-center justify-center text-white"
                        style={{ backgroundColor: platform.color }}
                      >
                        <i className={`fa-brands ${platform.icon}`}></i>
                      </div>
                      <div className="ml-3">
                        <div className="flex items-center">
                          <h4 className="font-medium">{platform.name}</h4>
                          {isConnected && (
                            <span className="ml-2 text-xs font-medium text-secondary bg-secondary/10 px-2 py-1 rounded-full">
                              {t('connect.connected')}
                            </span>
                          )}
                        </div>
                        {isConnected ? (
                          <p className="text-sm text-neutral-600">
                            {connectedAccount?.accountName}
                          </p>
                        ) : (
                          <p className="text-sm text-neutral-500">
                            {platform.description}
                          </p>
                        )}
                      </div>
                    </div>
                    <div>
                      {isConnected ? (
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => handleDisconnect(connectedAccount?.id || 0)}
                          disabled={disconnectMutation.isPending}
                        >
                          {disconnectMutation.isPending ? (
                            <div className="h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent"></div>
                          ) : (
                            t('connect.disconnect')
                          )}
                        </Button>
                      ) : platform.id === "twitter" ? (
                        <TwitterConnectButton onSuccess={() => queryClient.invalidateQueries({ queryKey: ['/api/social-accounts'] })} />
                      ) : platform.id === "facebook" ? (
                        <FacebookConnectButton onSuccess={() => queryClient.invalidateQueries({ queryKey: ['/api/social-accounts'] })} />
                      ) : platform.id === "instagram" ? (
                        <InstagramConnectButton onSuccess={() => queryClient.invalidateQueries({ queryKey: ['/api/social-accounts'] })} />
                      ) : (
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => handleConnect(platform.id)}
                        >
                          {t('connect.connect')}
                        </Button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Account Settings */}
      <Card>
        <CardContent className="p-6">
          <h3 className="font-semibold mb-6">{t('connect.accountSettings')}</h3>

          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-medium">{t('connect.autoPublish')}</h4>
                <p className="text-sm text-neutral-500">{t('connect.autoPublishDesc')}</p>
              </div>
              <Switch defaultChecked />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-medium">{t('connect.errorNotifications')}</h4>
                <p className="text-sm text-neutral-500">{t('connect.errorNotificationsDesc')}</p>
              </div>
              <Switch defaultChecked />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-medium">{t('connect.analytics')}</h4>
                <p className="text-sm text-neutral-500">{t('connect.analyticsDesc')}</p>
              </div>
              <Switch defaultChecked />
            </div>

            <div className="border-t border-neutral-100 pt-6">
              <h4 className="font-medium mb-3">{t('connect.refreshTokens')}</h4>
              <p className="text-sm text-neutral-500 mb-3">{t('connect.refreshTokensDesc')}</p>
              <Button variant="outline">
                <i className="fa-solid fa-rotate mr-2"></i>
                {t('connect.refreshAll')}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </>
  );
}
