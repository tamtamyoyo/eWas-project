import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useTranslation } from "react-i18next";

export default function TwitterCallback() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { t } = useTranslation();
  const [isProcessing, setIsProcessing] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const completeTwitterAuth = async () => {
      try {
        // Get the oauth_token and oauth_verifier from the URL
        const urlParams = new URLSearchParams(window.location.search);
        const oauthToken = urlParams.get("oauth_token");
        const oauthVerifier = urlParams.get("oauth_verifier");
        
        // Retrieve the stored tokens from localStorage
        const storedToken = localStorage.getItem("twitter_oauth_token");
        const storedTokenSecret = localStorage.getItem("twitter_oauth_token_secret");

        if (!oauthToken || !oauthVerifier || !storedToken || !storedTokenSecret || oauthToken !== storedToken) {
          setError(t("connect.twitter.invalidCallback"));
          setIsProcessing(false);
          return;
        }

        // Send the tokens to the server to complete the OAuth process
        const response = await apiRequest("POST", "/api/twitter/callback", {
          oauth_token: oauthToken,
          oauth_verifier: oauthVerifier,
          oauth_token_secret: storedTokenSecret
        });

        // Clear the stored tokens
        localStorage.removeItem("twitter_oauth_token");
        localStorage.removeItem("twitter_oauth_token_secret");

        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(errorData.message || "Failed to complete Twitter authentication");
        }

        // Show success message
        toast({
          title: t("connect.successTitle"),
          description: t("connect.twitter.accountConnected"),
        });

        // Redirect back to the connect page
        setLocation("/connect");
      } catch (error: any) {
        console.error("Twitter callback processing error:", error);
        setError(error.message || t("connect.twitter.callbackError"));
        setIsProcessing(false);
        
        toast({
          title: t("connect.errorTitle"),
          description: error.message || t("connect.twitter.callbackError"),
          variant: "destructive",
        });
        
        // Redirect after a delay
        setTimeout(() => {
          setLocation("/connect");
        }, 5000);
      }
    };

    completeTwitterAuth();
  }, []);

  return (
    <div className="flex min-h-screen flex-col items-center justify-center">
      <div className="w-full max-w-md text-center">
        <div className="mb-6">
          {isProcessing ? (
            <>
              <div className="mb-4 flex justify-center">
                <div className="h-10 w-10 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
              </div>
              <h1 className="text-xl font-bold">{t("common.processing")}</h1>
              <p className="text-neutral-500">{t("connect.twitter.completingAuth")}</p>
            </>
          ) : (
            <>
              <div className="mb-4 flex justify-center">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-red-100">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-6 w-6 text-red-600"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M6 18L18 6M6 6l12 12"
                    />
                  </svg>
                </div>
              </div>
              <h1 className="text-xl font-bold">{t("connect.errorTitle")}</h1>
              <p className="text-neutral-500">{error}</p>
              <p className="mt-4 text-sm">
                {t("connect.twitter.redirecting")}
              </p>
            </>
          )}
        </div>
      </div>
    </div>
  );
}