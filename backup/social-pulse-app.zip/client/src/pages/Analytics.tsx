import { useState } from "react";
import { useTranslation } from "react-i18next";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from "recharts";
import { useQuery } from "@tanstack/react-query";
import { formatNumber } from "@/lib/utils";

// Sample data structure that matches what would come from the API
type PlatformData = {
  name: string;
  color: string;
  followers: number;
  followersChange: number;
  engagement: number;
  engagementChange: number;
  posts: number;
  postsChange: number;
  reach: number;
  reachChange: number;
};

export default function Analytics() {
  const { t } = useTranslation();
  const [timeRange, setTimeRange] = useState("30");
  const [platform, setPlatform] = useState("all");

  // In a real implementation, we would fetch this data from the API
  const { data: userStats, isLoading } = useQuery({
    queryKey: ['/api/user-stats'],
  });

  // For the chart data
  const generateTimeSeriesData = (days: number) => {
    const data = [];
    const now = new Date();
    
    for (let i = days; i >= 0; i--) {
      const date = new Date();
      date.setDate(now.getDate() - i);
      
      // In a real implementation, this would be mapped from API data
      data.push({
        date: date.toISOString().slice(0, 10),
        followers: Math.floor(Math.random() * 50) + 950 + (days - i) * 10,
        engagement: Math.floor(Math.random() * 80) + 120 + (days - i) * 2,
        impressions: Math.floor(Math.random() * 300) + 700 + (days - i) * 15,
        clicks: Math.floor(Math.random() * 50) + 50 + (days - i),
      });
    }
    
    return data;
  };

  const chartData = generateTimeSeriesData(parseInt(timeRange));

  // Platform data - would come from API in real implementation
  const platforms: PlatformData[] = [
    {
      name: "Instagram",
      color: "#E1306C",
      followers: 12540,
      followersChange: 2.3,
      engagement: 4.2,
      engagementChange: 0.8,
      posts: 48,
      postsChange: 4.5,
      reach: 28600,
      reachChange: 3.2
    },
    {
      name: "Facebook",
      color: "#4267B2",
      followers: 8320,
      followersChange: 1.2,
      engagement: 2.8,
      engagementChange: -0.6,
      posts: 42,
      postsChange: 5.3,
      reach: 20400,
      reachChange: 2.1
    },
    {
      name: "Twitter",
      color: "#1DA1F2",
      followers: 5630,
      followersChange: 3.7,
      engagement: 3.5,
      engagementChange: 1.2,
      posts: 52,
      postsChange: 7.8,
      reach: 15200,
      reachChange: 4.5
    }
  ];

  // Engagement by content type data
  const contentTypeData = [
    { name: t('analytics.photos'), value: 42 },
    { name: t('analytics.videos'), value: 28 },
    { name: t('analytics.links'), value: 18 },
    { name: t('analytics.text'), value: 12 }
  ];

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
      </div>
    );
  }

  return (
    <>
      <div className="mb-6">
        <h1 className="text-2xl font-bold">{t('analytics.title')}</h1>
        <p className="text-neutral-500">{t('analytics.subtitle')}</p>
      </div>

      <div className="mb-6 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <Tabs defaultValue="overview" className="w-full sm:w-auto">
          <TabsList>
            <TabsTrigger value="overview">{t('analytics.overview')}</TabsTrigger>
            <TabsTrigger value="followers">{t('analytics.followers')}</TabsTrigger>
            <TabsTrigger value="engagement">{t('analytics.engagement')}</TabsTrigger>
            <TabsTrigger value="content">{t('analytics.content')}</TabsTrigger>
          </TabsList>
        </Tabs>

        <div className="flex items-center gap-2">
          <Select value={platform} onValueChange={setPlatform}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder={t('analytics.selectPlatform')} />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">{t('analytics.allPlatforms')}</SelectItem>
              <SelectItem value="instagram">Instagram</SelectItem>
              <SelectItem value="facebook">Facebook</SelectItem>
              <SelectItem value="twitter">Twitter</SelectItem>
            </SelectContent>
          </Select>

          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder={t('analytics.selectTimeRange')} />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7">{t('analytics.last7Days')}</SelectItem>
              <SelectItem value="30">{t('analytics.last30Days')}</SelectItem>
              <SelectItem value="90">{t('analytics.last90Days')}</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Performance Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {platforms.map((platform) => (
          <Card key={platform.name} className={platform.name.toLowerCase() === "instagram" ? "border-[#E1306C]/30" : ""}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <div 
                    className="w-8 h-8 rounded-full flex items-center justify-center text-white"
                    style={{ backgroundColor: platform.color }}
                  >
                    <i className={`fa-brands fa-${platform.name.toLowerCase()}`}></i>
                  </div>
                  <h3 className="font-medium">{platform.name}</h3>
                </div>
                <span className={`text-xs font-medium ${platform.followersChange >= 0 ? 'text-secondary bg-secondary/10' : 'text-status-error bg-status-error/10'} px-2 py-1 rounded-full`}>
                  {platform.followersChange >= 0 ? '+' : ''}{platform.followersChange}%
                </span>
              </div>
              <div className="mt-4 space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-neutral-500 text-sm">{t('analytics.followers')}</span>
                  <span className="font-semibold">{formatNumber(platform.followers)}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-neutral-500 text-sm">{t('analytics.engagement')}</span>
                  <span className="font-semibold">{platform.engagement}%</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-neutral-500 text-sm">{t('analytics.posts')}</span>
                  <span className="font-semibold">{platform.posts}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {/* Followers Growth Chart */}
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold">{t('analytics.followersGrowth')}</h3>
              <Button variant="ghost" size="sm">
                <i className="fa-solid fa-download mr-2"></i>
                {t('analytics.export')}
              </Button>
            </div>
            
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis 
                    dataKey="date" 
                    tick={{ fontSize: 12 }}
                    tickFormatter={(date) => {
                      const d = new Date(date);
                      return `${d.getDate()}/${d.getMonth() + 1}`;
                    }}
                  />
                  <YAxis tick={{ fontSize: 12 }} />
                  <Tooltip />
                  <Legend />
                  <Line 
                    type="monotone" 
                    dataKey="followers" 
                    name={t('analytics.followers')}
                    stroke="#3050F8" 
                    strokeWidth={2}
                    dot={false}
                    activeDot={{ r: 6 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Engagement Chart */}
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold">{t('analytics.engagementTrends')}</h3>
              <Button variant="ghost" size="sm">
                <i className="fa-solid fa-download mr-2"></i>
                {t('analytics.export')}
              </Button>
            </div>
            
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis 
                    dataKey="date" 
                    tick={{ fontSize: 12 }}
                    tickFormatter={(date) => {
                      const d = new Date(date);
                      return `${d.getDate()}/${d.getMonth() + 1}`;
                    }}
                  />
                  <YAxis tick={{ fontSize: 12 }} />
                  <Tooltip />
                  <Legend />
                  <Line 
                    type="monotone" 
                    dataKey="engagement" 
                    name={t('analytics.engagement')}
                    stroke="#FF9500" 
                    strokeWidth={2}
                    dot={false}
                    activeDot={{ r: 6 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* More Analytics Data */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        {/* Content Type Breakdown */}
        <Card>
          <CardContent className="p-6">
            <h3 className="font-semibold mb-4">{t('analytics.contentTypeBreakdown')}</h3>
            
            <div className="h-[250px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={contentTypeData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="value" name={t('analytics.percentage')} fill="#3050F8" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Top Performing Posts */}
        <Card className="lg:col-span-2">
          <CardContent className="p-6">
            <h3 className="font-semibold mb-4">{t('analytics.topPerformingPosts')}</h3>
            
            <div className="space-y-4">
              {[1, 2, 3].map((post) => (
                <div key={post} className="flex items-start space-x-4 rtl:space-x-reverse p-3 border border-neutral-100 rounded-lg">
                  <div className="bg-neutral-100 w-16 h-16 rounded-lg flex items-center justify-center">
                    <i className="fa-solid fa-image text-neutral-400"></i>
                  </div>
                  <div className="flex-1">
                    <p className="text-sm line-clamp-2">
                      {post === 1 ? t('analytics.postExample1') : 
                       post === 2 ? t('analytics.postExample2') : 
                       t('analytics.postExample3')}
                    </p>
                    <div className="flex items-center mt-2 text-xs text-neutral-500">
                      <span className="mr-3">{post === 1 ? "Instagram" : post === 2 ? "Twitter" : "Facebook"}</span>
                      <span className="mr-3">
                        <i className="fa-solid fa-heart mr-1"></i>
                        {post === 1 ? "842" : post === 2 ? "563" : "321"}
                      </span>
                      <span className="mr-3">
                        <i className="fa-solid fa-comment mr-1"></i>
                        {post === 1 ? "54" : post === 2 ? "37" : "19"}
                      </span>
                      <span>
                        <i className="fa-solid fa-share mr-1"></i>
                        {post === 1 ? "21" : post === 2 ? "15" : "8"}
                      </span>
                    </div>
                  </div>
                  <div className="text-xs font-medium text-secondary bg-secondary/10 px-2 py-1 rounded-full whitespace-nowrap">
                    {post === 1 ? "+142%" : post === 2 ? "+98%" : "+67%"}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Download Reports Section */}
      <Card className="mb-8">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="font-semibold text-lg">{t('analytics.downloadReports')}</h3>
              <p className="text-neutral-500 text-sm">{t('analytics.downloadReportsDescription')}</p>
            </div>
            <Button>
              <i className="fa-solid fa-file-export mr-2"></i>
              {t('analytics.generateReport')}
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="border border-neutral-100 rounded-lg p-4 hover:border-neutral-300 transition-all">
              <div className="flex items-center mb-3">
                <i className="fa-solid fa-chart-line text-primary mr-2"></i>
                <h4 className="font-medium">{t('analytics.performanceReport')}</h4>
              </div>
              <p className="text-sm text-neutral-500 mb-4">{t('analytics.performanceReportDescription')}</p>
              <Button variant="outline" size="sm" className="w-full">
                <i className="fa-solid fa-download mr-2"></i>
                {t('analytics.download')}
              </Button>
            </div>

            <div className="border border-neutral-100 rounded-lg p-4 hover:border-neutral-300 transition-all">
              <div className="flex items-center mb-3">
                <i className="fa-solid fa-users text-accent mr-2"></i>
                <h4 className="font-medium">{t('analytics.audienceReport')}</h4>
              </div>
              <p className="text-sm text-neutral-500 mb-4">{t('analytics.audienceReportDescription')}</p>
              <Button variant="outline" size="sm" className="w-full">
                <i className="fa-solid fa-download mr-2"></i>
                {t('analytics.download')}
              </Button>
            </div>

            <div className="border border-neutral-100 rounded-lg p-4 hover:border-neutral-300 transition-all">
              <div className="flex items-center mb-3">
                <i className="fa-solid fa-file-lines text-secondary mr-2"></i>
                <h4 className="font-medium">{t('analytics.contentReport')}</h4>
              </div>
              <p className="text-sm text-neutral-500 mb-4">{t('analytics.contentReportDescription')}</p>
              <Button variant="outline" size="sm" className="w-full">
                <i className="fa-solid fa-download mr-2"></i>
                {t('analytics.download')}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </>
  );
}
