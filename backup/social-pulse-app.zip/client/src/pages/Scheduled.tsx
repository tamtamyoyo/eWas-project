import { useTranslation } from "react-i18next";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { type Post } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { formatDate, getPlatformColor, getPlatformIcon } from "@/lib/utils";

export default function Scheduled() {
  const { t } = useTranslation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const { data: scheduledPosts, isLoading } = useQuery<Post[]>({
    queryKey: ['/api/posts/scheduled'],
  });
  
  const deletePostMutation = useMutation({
    mutationFn: async (postId: number) => {
      await apiRequest("DELETE", `/api/posts/${postId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/posts/scheduled'] });
      toast({
        title: t('scheduled.deleteSuccess'),
        description: t('scheduled.deleteSuccessMessage'),
      });
    },
    onError: (error: any) => {
      toast({
        title: t('scheduled.deleteError'),
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  const handleDelete = (postId: number) => {
    if (confirm(t('scheduled.confirmDelete'))) {
      deletePostMutation.mutate(postId);
    }
  };
  
  return (
    <>
      <div className="mb-6">
        <h1 className="text-2xl font-bold">{t('scheduled.title')}</h1>
        <p className="text-neutral-500">{t('scheduled.subtitle')}</p>
      </div>
      
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="font-semibold">{t('scheduled.upcomingPosts')}</h3>
            <Button variant="outline" onClick={() => window.location.href = "/compose"}>
              <i className="fa-solid fa-plus mr-2"></i>
              {t('scheduled.newScheduledPost')}
            </Button>
          </div>
          
          {isLoading ? (
            <div className="flex justify-center py-12">
              <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
            </div>
          ) : !scheduledPosts || scheduledPosts.length === 0 ? (
            <div className="text-center py-12 border-2 border-dashed border-neutral-200 rounded-lg">
              <i className="fa-solid fa-calendar text-4xl text-neutral-300 mb-4"></i>
              <h3 className="font-medium text-lg mb-2">{t('scheduled.noPosts')}</h3>
              <p className="text-neutral-500 mb-4">{t('scheduled.noPostsMessage')}</p>
              <Button onClick={() => window.location.href = "/compose"}>
                {t('scheduled.scheduleNow')}
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {scheduledPosts.map((post) => (
                <div 
                  key={post.id} 
                  className="border border-neutral-100 rounded-lg p-4 hover:shadow-sm transition-shadow"
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <i className="fa-solid fa-calendar-day text-primary"></i>
                      <span className="font-medium">
                        {formatDate(post.scheduledAt || new Date())}
                      </span>
                      {post.scheduledAt && (
                        <span className="text-neutral-500">
                          {new Date(post.scheduledAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      )}
                    </div>
                    <div className="flex space-x-2">
                      <Button variant="ghost" size="sm">
                        <i className="fa-solid fa-pencil"></i>
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => handleDelete(post.id)}
                        disabled={deletePostMutation.isPending}
                      >
                        <i className="fa-solid fa-trash text-red-500"></i>
                      </Button>
                    </div>
                  </div>
                  
                  <p className="text-neutral-700 mb-4">{post.content}</p>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex space-x-2">
                      {post.platforms.map((platform) => (
                        <div 
                          key={platform}
                          className="w-6 h-6 rounded-full flex items-center justify-center text-white"
                          style={{ backgroundColor: getPlatformColor(platform) }}
                        >
                          <i className={`fa-brands ${getPlatformIcon(platform)}`}></i>
                        </div>
                      ))}
                    </div>
                    <span className="text-xs bg-neutral-100 text-neutral-600 px-2 py-1 rounded-full">
                      {t('scheduled.scheduledStatus')}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </>
  );
}
