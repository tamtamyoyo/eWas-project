import { useState, useEffect } from 'react';
import { useStripe, useElements, PaymentElement, Elements, AddressElement } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from 'wouter';
import { apiRequest } from '@/lib/queryClient';
import { useAuth } from '@/hooks/useAuth';
import { useTranslation } from 'react-i18next';
import { ArrowLeft, Check, CreditCard, Loader2 } from 'lucide-react';
import AppLayout from '@/components/layout/AppLayout';

// Make sure to call loadStripe outside of a component's render to avoid
// recreating the Stripe object on every render.
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

function SubscriptionForm() {
  const { t } = useTranslation();
  const stripe = useStripe();
  const elements = useElements();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentMessage, setPaymentMessage] = useState('');
  const [paymentSuccess, setPaymentSuccess] = useState(false);
  
  // Handle form submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!stripe || !elements) {
      // Stripe.js has not yet loaded.
      // Make sure to disable form submission until Stripe.js has loaded.
      return;
    }

    setIsProcessing(true);

    try {
      const { error } = await stripe.confirmPayment({
        elements,
        confirmParams: {
          return_url: `${window.location.origin}/dashboard`,
        },
      });

      if (error) {
        setPaymentMessage(error.message || t('subscribe.defaultError'));
        toast({
          title: t('subscribe.paymentFailed'),
          description: error.message,
          variant: "destructive",
        });
      } else {
        setPaymentSuccess(true);
        setPaymentMessage(t('subscribe.subscriptionActive'));
        toast({
          title: t('subscribe.subscriptionActive'),
          description: t('subscribe.thankYouSubscribe'),
        });
        
        // Redirect to dashboard after successful payment
        setTimeout(() => {
          setLocation('/dashboard');
        }, 2000);
      }
    } catch (err: any) {
      setPaymentMessage(err.message || t('subscribe.defaultError'));
      toast({
        title: t('subscribe.paymentFailed'),
        description: err.message,
        variant: "destructive",
      });
    }

    setIsProcessing(false);
  };

  if (paymentSuccess) {
    return (
      <div className="flex flex-col items-center justify-center text-center p-6">
        <div className="w-16 h-16 flex items-center justify-center rounded-full bg-green-100 text-green-600 dark:bg-green-900 dark:text-green-400 mb-4">
          <Check size={32} />
        </div>
        <h2 className="text-2xl font-bold mb-2">{t('subscribe.subscriptionActive')}</h2>
        <p className="text-muted-foreground mb-6">{t('subscribe.redirecting')}</p>
        <div className="animate-spin w-6 h-6 border-2 border-primary border-t-transparent rounded-full"></div>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="space-y-4">
        <div>
          <h3 className="text-sm font-medium mb-2">{t('subscribe.billingDetails')}</h3>
          <AddressElement 
            options={{
              mode: 'billing',
            }} 
          />
        </div>
        
        <div>
          <h3 className="text-sm font-medium mb-2">{t('subscribe.paymentMethod')}</h3>
          <PaymentElement />
        </div>
      </div>
      
      {paymentMessage && (
        <div className="p-3 bg-red-50 text-red-600 dark:bg-red-900/30 dark:text-red-400 rounded-md text-sm">
          {paymentMessage}
        </div>
      )}
      
      <Button 
        type="submit" 
        className="w-full"
        disabled={!stripe || isProcessing}
      >
        {isProcessing ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            {t('subscribe.processing')}
          </>
        ) : (
          <>
            <CreditCard className="mr-2 h-4 w-4" />
            {t('subscribe.subscribe')}
          </>
        )}
      </Button>
    </form>
  );
}

export default function Subscribe() {
  const { t } = useTranslation();
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  // Get query parameters from the URL
  const [location] = useLocation();
  const query = Object.fromEntries(new URLSearchParams(location.split('?')[1] || ''));
  const planId = query.plan;
  const amount = query.amount ? parseInt(query.amount, 10) : 0;
  const planName = query.name || 'Subscription';
  const interval = query.interval || 'monthly';
  
  const [clientSecret, setClientSecret] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!planId) {
      setError('Plan selection is required');
      setLoading(false);
      return;
    }

    // Calculate price amount based on plan and interval
    let priceAmount = 0;
    let selectedPlanName = '';
    
    switch (planId) {
      case 'starter':
        priceAmount = 900; // $9.00 in cents
        selectedPlanName = 'Starter Plan';
        break;
      case 'business':
        priceAmount = 1900; // $19.00 in cents
        selectedPlanName = 'Business Plan';
        break;
      case 'agency':
        priceAmount = 2900; // $29.00 in cents
        selectedPlanName = 'Agency Plan';
        break;
      default:
        // Free plan
        setPaymentSuccess(true);
        setLoading(false);
        return;
    }
    
    // Apply yearly discount if applicable
    if (interval === 'yearly') {
      priceAmount = priceAmount * 12 * 0.8; // 20% discount for yearly
    }

    const fetchSubscription = async () => {
      try {
        console.log('Creating subscription with:', { planId, priceAmount, interval, planName: selectedPlanName });
        
        const response = await apiRequest('POST', '/api/get-or-create-subscription', {
          planId,
          priceAmount,
          interval,
          planName: selectedPlanName,
        });
        
        const data = await response.json();
        
        if (data.clientSecret) {
          setClientSecret(data.clientSecret);
        } else if (data.subscriptionId) {
          // Already has an active subscription
          setPaymentSuccess(true);
        }
      } catch (err: any) {
        console.error('Subscription creation error:', err);
        setError(err.message || 'Failed to create subscription');
      } finally {
        setLoading(false);
      }
    };
    
    if (user) {
      fetchSubscription();
    }
  }, [planId, interval, user]);

  // For displaying subscription success message when already subscribed
  const [paymentSuccess, setPaymentSuccess] = useState(false);

  if (paymentSuccess) {
    return (
      <AppLayout>
        <div className="container max-w-3xl mx-auto py-8">
          <Card>
            <CardContent className="pt-6">
              <div className="flex flex-col items-center justify-center text-center p-6">
                <div className="w-16 h-16 flex items-center justify-center rounded-full bg-green-100 text-green-600 dark:bg-green-900 dark:text-green-400 mb-4">
                  <Check size={32} />
                </div>
                <h2 className="text-2xl font-bold mb-2">{t('subscribe.alreadySubscribed')}</h2>
                <p className="text-muted-foreground mb-6">{t('subscribe.activeSubscription')}</p>
                <Button onClick={() => setLocation('/dashboard')}>
                  {t('subscribe.backToDashboard')}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="container max-w-3xl mx-auto py-8">
        <Button
          variant="ghost"
          onClick={() => setLocation('/dashboard')}
          className="mb-6"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          {t('subscribe.backToDashboard')}
        </Button>
        
        <Card>
          <CardHeader>
            <CardTitle>{t('subscribe.subscribeTitle')}</CardTitle>
            <CardDescription>
              {t('subscribe.completeSubscription')}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="mb-6 bg-muted/50 p-4 rounded-lg">
              <h3 className="font-medium mb-1">{t('subscription.billingDetails')}</h3>
              <div className="flex justify-between py-2 border-b border-border">
                <span>
                {planId === 'starter' ? t('plans.starter') : 
                 planId === 'business' ? t('plans.business') : 
                 planId === 'agency' ? t('plans.agency') : t('plans.free')}
                </span>
                <span className="font-medium">
                  {planId === 'starter' ? '$9' : 
                   planId === 'business' ? '$19' : 
                   planId === 'agency' ? '$29' : '$0'}{' '}
                  <span className="text-muted-foreground text-sm">
                    /{t('subscription.month')}
                  </span>
                </span>
              </div>
              <div className="flex justify-between py-2 font-bold">
                <span>
                  {interval === 'yearly' ? t('subscription.billedYearly').replace('${{total}}', 
                    (planId === 'starter' ? '86.40' : 
                     planId === 'business' ? '182.40' : 
                     planId === 'agency' ? '278.40' : '0')
                  ) : t('subscription.billedMonthly')}
                </span>
                <span>
                  {planId === 'starter' ? 
                    (interval === 'yearly' ? '$86.40' : '$9') : 
                   planId === 'business' ? 
                    (interval === 'yearly' ? '$182.40' : '$19') : 
                   planId === 'agency' ? 
                    (interval === 'yearly' ? '$278.40' : '$29') : 
                   '$0'}
                </span>
              </div>
            </div>
            
            {loading ? (
              <div className="flex justify-center py-8">
                <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" aria-label="Loading"/>
              </div>
            ) : error ? (
              <div className="p-6 text-center">
                <p className="text-red-500 dark:text-red-400 mb-4">{error}</p>
                <Button onClick={() => setLocation('/dashboard')}>
                  {t('subscribe.backToDashboard')}
                </Button>
              </div>
            ) : (
              clientSecret && (
                <Elements 
                  stripe={stripePromise} 
                  options={{ 
                    clientSecret,
                    appearance: {
                      theme: 'stripe',
                    },
                  }}
                >
                  <SubscriptionForm />
                </Elements>
              )
            )}
          </CardContent>
          <CardFooter className="border-t flex justify-center text-xs text-muted-foreground">
            <div className="text-center max-w-xs">
              {t('subscribe.securePayment')}
              {interval === 'monthly' && (
                <p className="mt-1">{t('subscribe.cancelAnytime')}</p>
              )}
            </div>
          </CardFooter>
        </Card>
      </div>
    </AppLayout>
  );
}