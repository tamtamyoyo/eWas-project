import { useState, useEffect } from "react";
import { useTranslation } from "react-i18next";
import { Card, CardContent } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { type SocialAccount } from "@shared/schema";

export default function Compose() {
  const { t } = useTranslation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [content, setContent] = useState("");
  const [scheduledDate, setScheduledDate] = useState("");
  const [scheduledTime, setScheduledTime] = useState("");
  const [selectedPlatforms, setSelectedPlatforms] = useState<string[]>([]);
  
  const { data: socialAccounts, isLoading } = useQuery<SocialAccount[]>({
    queryKey: ['/api/social-accounts'],
  });
  
  const connectedAccounts = socialAccounts?.filter(account => account.isConnected) || [];
  
  // Effect to set default time to current time + 1 hour
  useEffect(() => {
    const now = new Date();
    now.setHours(now.getHours() + 1);
    
    const formatDate = (date: Date) => {
      return date.toISOString().slice(0, 10);
    };
    
    const formatTime = (date: Date) => {
      return date.toTimeString().slice(0, 5);
    };
    
    setScheduledDate(formatDate(now));
    setScheduledTime(formatTime(now));
  }, []);
  
  const createPostMutation = useMutation({
    mutationFn: async (postData: any) => {
      const response = await apiRequest("POST", "/api/posts", postData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/posts'] });
      queryClient.invalidateQueries({ queryKey: ['/api/posts/scheduled'] });
      
      toast({
        title: t('compose.successTitle'),
        description: t('compose.successMessage'),
      });
      
      // Reset form
      setContent("");
      setSelectedPlatforms([]);
    },
    onError: (error: any) => {
      toast({
        title: t('compose.errorTitle'),
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  const handleSubmit = (publish: boolean) => {
    if (!content.trim()) {
      toast({
        title: t('compose.validationError'),
        description: t('compose.contentRequired'),
        variant: "destructive",
      });
      return;
    }
    
    if (selectedPlatforms.length === 0) {
      toast({
        title: t('compose.validationError'),
        description: t('compose.platformRequired'),
        variant: "destructive",
      });
      return;
    }
    
    let scheduledAt = null;
    
    if (!publish && (!scheduledDate || !scheduledTime)) {
      toast({
        title: t('compose.validationError'),
        description: t('compose.scheduleTimeRequired'),
        variant: "destructive",
      });
      return;
    }
    
    if (!publish) {
      scheduledAt = new Date(`${scheduledDate}T${scheduledTime}`);
      
      if (scheduledAt < new Date()) {
        toast({
          title: t('compose.validationError'),
          description: t('compose.schedulePastError'),
          variant: "destructive",
        });
        return;
      }
    }
    
    createPostMutation.mutate({
      content,
      platforms: selectedPlatforms,
      scheduledAt: scheduledAt?.toISOString() || null,
      status: publish ? "published" : "scheduled",
      mediaUrls: []
    });
  };
  
  const handlePlatformToggle = (platform: string) => {
    setSelectedPlatforms(prev => 
      prev.includes(platform)
        ? prev.filter(p => p !== platform)
        : [...prev, platform]
    );
  };
  
  return (
    <>
      <div className="mb-6">
        <h1 className="text-2xl font-bold">{t('compose.title')}</h1>
        <p className="text-neutral-500">{t('compose.subtitle')}</p>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2">
          <CardContent className="p-6">
            <div className="mb-6">
              <Label htmlFor="content">{t('compose.content')}</Label>
              <Textarea
                id="content"
                placeholder={t('compose.contentPlaceholder')}
                className="mt-2 min-h-[200px]"
                value={content}
                onChange={(e) => setContent(e.target.value)}
              />
              <div className="mt-2 text-sm text-right text-neutral-500">
                {content.length} / 280
              </div>
            </div>
            
            <div className="mb-6">
              <Label>{t('compose.mediaUpload')}</Label>
              <div className="mt-2 border-2 border-dashed border-neutral-200 rounded-lg p-8 text-center">
                <i className="fa-solid fa-image text-2xl text-neutral-400 mb-2"></i>
                <p className="text-neutral-600">{t('compose.dragDrop')}</p>
                <Button variant="outline" size="sm" className="mt-4">
                  {t('compose.browseFiles')}
                </Button>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
              <div>
                <Label htmlFor="date">{t('compose.date')}</Label>
                <Input
                  id="date"
                  type="date"
                  className="mt-2"
                  value={scheduledDate}
                  onChange={(e) => setScheduledDate(e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="time">{t('compose.time')}</Label>
                <Input
                  id="time"
                  type="time"
                  className="mt-2"
                  value={scheduledTime}
                  onChange={(e) => setScheduledTime(e.target.value)}
                />
              </div>
            </div>
            
            <div className="flex flex-wrap gap-4">
              <Button 
                variant="default" 
                onClick={() => handleSubmit(true)}
                disabled={createPostMutation.isPending}
              >
                {createPostMutation.isPending ? (
                  <div className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent"></div>
                ) : (
                  <>
                    <i className="fa-solid fa-paper-plane mr-2"></i>
                    {t('compose.publishNow')}
                  </>
                )}
              </Button>
              <Button 
                variant="outline" 
                onClick={() => handleSubmit(false)}
                disabled={createPostMutation.isPending}
              >
                <i className="fa-solid fa-clock mr-2"></i>
                {t('compose.schedule')}
              </Button>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <h3 className="font-semibold mb-4">{t('compose.platforms')}</h3>
            
            {isLoading ? (
              <div className="flex justify-center py-8">
                <div className="h-6 w-6 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
              </div>
            ) : (
              <div className="space-y-3">
                {connectedAccounts.length === 0 ? (
                  <p className="text-neutral-500 text-center py-4">
                    {t('compose.noConnectedAccounts')}
                  </p>
                ) : (
                  connectedAccounts.map((account) => (
                    <div key={account.id} className="flex items-center space-x-2">
                      <Checkbox
                        id={`platform-${account.id}`}
                        checked={selectedPlatforms.includes(account.platform)}
                        onCheckedChange={() => handlePlatformToggle(account.platform)}
                      />
                      <Label 
                        htmlFor={`platform-${account.id}`}
                        className="flex items-center space-x-2 cursor-pointer"
                      >
                        <div 
                          className="w-6 h-6 rounded-full flex items-center justify-center text-white"
                          style={{ 
                            backgroundColor: 
                              account.platform === 'facebook' ? '#4267B2' :
                              account.platform === 'instagram' ? '#E1306C' :
                              account.platform === 'twitter' ? '#1DA1F2' :
                              account.platform === 'linkedin' ? '#0077B5' :
                              account.platform === 'snapchat' ? '#FFFC00' : '#6B7280'
                          }}
                        >
                          <i className={`fa-brands fa-${
                            account.platform === 'facebook' ? 'facebook-f' :
                            account.platform === 'instagram' ? 'instagram' :
                            account.platform === 'twitter' ? 'twitter' :
                            account.platform === 'linkedin' ? 'linkedin-in' :
                            account.platform === 'snapchat' ? 'snapchat' : 'globe'
                          }`}></i>
                        </div>
                        <span>{account.accountName}</span>
                      </Label>
                    </div>
                  ))
                )}
                
                {connectedAccounts.length > 0 && (
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="mt-4 w-full"
                    onClick={() => setSelectedPlatforms(
                      selectedPlatforms.length === connectedAccounts.length
                        ? []
                        : connectedAccounts.map(a => a.platform)
                    )}
                  >
                    {selectedPlatforms.length === connectedAccounts.length
                      ? t('compose.deselectAll')
                      : t('compose.selectAll')}
                  </Button>
                )}
              </div>
            )}
            
            <div className="mt-8">
              <h3 className="font-semibold mb-4">{t('compose.bestTimeToPost')}</h3>
              <Select defaultValue="automatic">
                <SelectTrigger>
                  <SelectValue placeholder={t('compose.selectTime')} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="automatic">{t('compose.automatic')}</SelectItem>
                  <SelectItem value="morning">{t('compose.morning')}</SelectItem>
                  <SelectItem value="afternoon">{t('compose.afternoon')}</SelectItem>
                  <SelectItem value="evening">{t('compose.evening')}</SelectItem>
                </SelectContent>
              </Select>
              <p className="text-sm text-neutral-500 mt-2">
                {t('compose.bestTimeDescription')}
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
