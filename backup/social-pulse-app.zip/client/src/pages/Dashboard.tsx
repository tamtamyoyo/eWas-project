import { useTranslation } from "react-i18next";
import { useLocation } from "wouter";
import StatsOverview from "@/components/dashboard/StatsOverview";
import AudienceGrowthChart from "@/components/dashboard/AudienceGrowthChart";
import EngagementChart from "@/components/dashboard/EngagementChart";
import RecentActivities from "@/components/dashboard/RecentActivities";
import ConnectedPlatforms from "@/components/dashboard/ConnectedPlatforms";
import SubscriptionPlans from "@/components/dashboard/SubscriptionPlans";
import SubscriptionStatus from "@/components/dashboard/SubscriptionStatus";

export default function Dashboard() {
  const { t } = useTranslation();
  const [, setLocation] = useLocation();
  
  const handleUpgrade = () => {
    setLocation('/subscribe');
  };
  
  return (
    <>
      {/* Page title */}
      <div className="mb-6">
        <h1 className="text-2xl font-bold">{t('dashboard.title')}</h1>
        <p className="text-neutral-500">{t('dashboard.subtitle')}</p>
      </div>
      
      {/* Stats overview */}
      <StatsOverview />
      
      {/* Subscription status & Performance charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <div>
          <SubscriptionStatus onUpgrade={handleUpgrade} />
        </div>
        <div className="lg:col-span-2">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <AudienceGrowthChart />
            <EngagementChart />
          </div>
        </div>
      </div>
      
      {/* Recent activities & platform connections */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <RecentActivities />
        <ConnectedPlatforms />
      </div>
      
      {/* Subscription Plans */}
      <SubscriptionPlans />
    </>
  );
}
