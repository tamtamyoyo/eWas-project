import { Switch, Route } from "wouter";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/Dashboard";
import Login from "@/pages/Login";
import Register from "@/pages/Register";
import Compose from "@/pages/Compose";
import Scheduled from "@/pages/Scheduled";
import Analytics from "@/pages/Analytics";
import Connect from "@/pages/Connect";
import Settings from "@/pages/Settings";
import ContentAnalyzer from "@/pages/ContentAnalyzer";
import TwitterCallback from "@/pages/TwitterCallback";
import FacebookCallback from "@/pages/FacebookCallback";
import InstagramCallback from "@/pages/InstagramCallback";
import { useAuth } from "@/hooks/useAuth";
import AppLayout from "@/components/layout/AppLayout";

function ProtectedRoute({ component: Component, ...rest }: any) {
  const { user, loading } = useAuth();
  
  if (loading) {
    return (
      <div className="flex h-screen w-full items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
      </div>
    );
  }
  
  if (!user) {
    window.location.href = "/login";
    return null;
  }
  
  return <Component {...rest} />;
}

function App() {
  return (
    <>
      <Switch>
        <Route path="/login" component={Login} />
        <Route path="/register" component={Register} />
        <Route path="/">
          <AppLayout>
            <ProtectedRoute component={Dashboard} />
          </AppLayout>
        </Route>
        <Route path="/compose">
          <AppLayout>
            <ProtectedRoute component={Compose} />
          </AppLayout>
        </Route>
        <Route path="/scheduled">
          <AppLayout>
            <ProtectedRoute component={Scheduled} />
          </AppLayout>
        </Route>
        <Route path="/analytics">
          <AppLayout>
            <ProtectedRoute component={Analytics} />
          </AppLayout>
        </Route>
        <Route path="/connect">
          <AppLayout>
            <ProtectedRoute component={Connect} />
          </AppLayout>
        </Route>
        <Route path="/settings">
          <AppLayout>
            <ProtectedRoute component={Settings} />
          </AppLayout>
        </Route>
        <Route path="/content-analyzer">
          <AppLayout>
            <ProtectedRoute component={ContentAnalyzer} />
          </AppLayout>
        </Route>
        <Route path="/auth/twitter/callback" component={TwitterCallback} />
        <Route path="/auth/facebook/callback" component={FacebookCallback} />
        <Route path="/auth/instagram/callback" component={InstagramCallback} />
        <Route component={NotFound} />
      </Switch>
      <Toaster />
    </>
  );
}

export default App;
