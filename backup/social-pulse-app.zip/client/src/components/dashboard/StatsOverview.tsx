import { Card, CardContent } from "@/components/ui/card";
import { useTranslation } from "react-i18next";
import { formatNumber, formatPercentage } from "@/lib/utils";

type StatProps = {
  title: string;
  value: number | string;
  change: number;
  description: string;
};

function Stat({ title, value, change, description }: StatProps) {
  const isPositiveChange = change >= 0;
  
  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-neutral-500 font-medium">{title}</h3>
          <span className={`text-xs font-medium ${isPositiveChange ? 'text-secondary bg-secondary/10' : 'text-status-error bg-status-error/10'} px-2 py-1 rounded-full`}>
            {isPositiveChange ? '+' : ''}{formatPercentage(change)}
          </span>
        </div>
        <div className="flex items-baseline">
          <span className="text-2xl font-bold">{value}</span>
          <span className="text-neutral-500 text-sm ml-2">{description}</span>
        </div>
      </CardContent>
    </Card>
  );
}

export default function StatsOverview() {
  const { t } = useTranslation();
  
  // In a real app, this would come from the API
  const stats = {
    followers: 24832,
    followersChange: 5.2,
    engagement: 3.7,
    engagementChange: -1.8,
    posts: 128,
    postsChange: 12.5,
    ctr: 5.2,
    ctrChange: 2.1
  };
  
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
      <Stat 
        title={t('stats.totalFollowers')} 
        value={formatNumber(stats.followers)} 
        change={stats.followersChange} 
        description={t('stats.acrossPlatforms')} 
      />
      
      <Stat 
        title={t('stats.engagementRate')} 
        value={formatPercentage(stats.engagement)} 
        change={stats.engagementChange} 
        description={t('stats.avgPerPost')} 
      />
      
      <Stat 
        title={t('stats.postsPublished')} 
        value={stats.posts.toString()} 
        change={stats.postsChange} 
        description={t('stats.thisMonth')} 
      />
      
      <Stat 
        title={t('stats.clickThroughRate')} 
        value={formatPercentage(stats.ctr)} 
        change={stats.ctrChange} 
        description={t('stats.avgPerPost')} 
      />
    </div>
  );
}
