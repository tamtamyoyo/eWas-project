import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { useTranslation } from "react-i18next";
import { useAuth } from "@/hooks/useAuth";

type SidebarItemProps = {
  href: string;
  icon: string;
  children: React.ReactNode;
  active?: boolean;
};

function SidebarItem({ href, icon, children, active }: SidebarItemProps) {
  return (
    <Link href={href}>
      <a
        className={cn(
          "flex items-center space-x-3 rtl:space-x-reverse px-4 py-3 rounded-lg text-neutral-700 hover:bg-neutral-100 transition-colors",
          active && "bg-primary/10 text-primary"
        )}
      >
        <i className={`fa-solid ${icon} w-5`}></i>
        <span>{children}</span>
      </a>
    </Link>
  );
}

export default function Sidebar() {
  const [location] = useLocation();
  const { t } = useTranslation();
  const { user } = useAuth();

  return (
    <aside className="hidden md:flex md:flex-col w-64 bg-white border-r border-neutral-100 h-full">
      {/* Logo */}
      <div className="flex items-center justify-center h-16 border-b border-neutral-100 px-6">
        <span className="text-xl font-bold text-primary">Social<span className="text-accent">Pulse</span></span>
        <span className="rtl:mr-2 ltr:ml-2 text-xs text-neutral-500 font-inter">{t('common.brandSubtitle')}</span>
      </div>
      
      {/* User profile summary */}
      {user && (
        <div className="p-4 border-b border-neutral-100">
          <div className="flex items-center space-x-3 rtl:space-x-reverse">
            <div className="w-10 h-10 rounded-full bg-neutral-200 flex items-center justify-center uppercase font-bold text-primary">
              {user.fullName ? user.fullName.charAt(0) : user.username.charAt(0)}
            </div>
            <div>
              <h3 className="font-medium">{user.fullName || user.username}</h3>
              <p className="text-xs text-neutral-500">{t(`plans.${user.currentPlan || 'free'}`)}</p>
            </div>
          </div>
        </div>
      )}
      
      {/* Menu items */}
      <nav className="flex-1 overflow-y-auto p-4">
        <div className="space-y-1">
          <SidebarItem href="/" icon="fa-chart-simple" active={location === "/"}>
            {t('sidebar.dashboard')}
          </SidebarItem>
          <SidebarItem href="/compose" icon="fa-pen-to-square" active={location === "/compose"}>
            {t('sidebar.compose')}
          </SidebarItem>
          <SidebarItem href="/scheduled" icon="fa-calendar" active={location === "/scheduled"}>
            {t('sidebar.scheduled')}
          </SidebarItem>
          <SidebarItem href="/analytics" icon="fa-chart-line" active={location === "/analytics"}>
            {t('sidebar.analytics')}
          </SidebarItem>
          <SidebarItem href="/connect" icon="fa-link" active={location === "/connect"}>
            {t('sidebar.connect')}
          </SidebarItem>
          <SidebarItem href="/content-analyzer" icon="fa-brain" active={location === "/content-analyzer"}>
            {t('sidebar.contentAnalyzer', 'Content Analyzer')}
          </SidebarItem>
        </div>
        
        <div className="mt-8 pt-4 border-t border-neutral-100">
          <h4 className="text-xs font-semibold text-neutral-500 uppercase px-4 mb-2">
            {t('sidebar.settingsHeader')}
          </h4>
          <div className="space-y-1">
            <SidebarItem href="/settings" icon="fa-user" active={location === "/settings"}>
              {t('sidebar.account')}
            </SidebarItem>
            <SidebarItem href="/settings?tab=subscription" icon="fa-credit-card" active={location === "/settings?tab=subscription"}>
              {t('sidebar.subscription')}
            </SidebarItem>
            <SidebarItem href="/settings?tab=help" icon="fa-circle-question" active={location === "/settings?tab=help"}>
              {t('sidebar.help')}
            </SidebarItem>
          </div>
        </div>
      </nav>
      
      {/* Language switcher in sidebar */}
      <div className="p-4 border-t border-neutral-100">
        <LanguageSwitcher />
      </div>
    </aside>
  );
}

function LanguageSwitcher() {
  const { t, i18n } = useTranslation();
  const currentLanguage = i18n.language;
  
  const toggleLanguage = () => {
    const newLanguage = currentLanguage === 'en' ? 'ar' : 'en';
    i18n.changeLanguage(newLanguage);
  };
  
  return (
    <button 
      className="flex items-center text-sm text-neutral-600 hover:text-primary transition-colors"
      onClick={toggleLanguage}
    >
      <i className="fa-solid fa-globe w-5"></i>
      <span className="mr-1">{currentLanguage === 'en' ? 'English' : 'العربية'}</span>
      <i className="fa-solid fa-chevron-down text-xs"></i>
    </button>
  );
}
