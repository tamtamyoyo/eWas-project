import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useTranslation } from "react-i18next";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import Sidebar from "./Sidebar";

type TopNavProps = {
  onNewPost?: () => void;
};

export default function TopNav({ onNewPost }: TopNavProps) {
  const { t, i18n } = useTranslation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  
  const toggleLanguage = () => {
    const currentLanguage = i18n.language;
    const newLanguage = currentLanguage === 'en' ? 'ar' : 'en';
    i18n.changeLanguage(newLanguage);
  };

  return (
    <header className="bg-white border-b border-neutral-100 h-16 flex items-center justify-between px-4 md:px-6">
      {/* Mobile menu button */}
      <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
        <SheetTrigger asChild>
          <Button variant="ghost" size="icon" className="md:hidden">
            <i className="fa-solid fa-bars"></i>
          </Button>
        </SheetTrigger>
        <SheetContent side="left" className="p-0 w-64">
          <Sidebar />
        </SheetContent>
      </Sheet>
      
      {/* Search */}
      <div className="hidden md:flex items-center">
        <div className="relative">
          <Input
            type="text"
            placeholder={t('common.search')}
            className="bg-neutral-50 border border-neutral-100 rounded-lg py-2 pl-10 pr-4 w-60 focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
          />
          <i className="fa-solid fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-neutral-400"></i>
        </div>
      </div>
      
      {/* Quick actions */}
      <div className="flex items-center space-x-4 rtl:space-x-reverse">
        <Button variant="ghost" size="icon">
          <i className="fa-solid fa-bell"></i>
        </Button>
        
        <Button 
          onClick={onNewPost}
          className="hidden sm:flex items-center px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary-dark transition-colors"
        >
          <i className="fa-solid fa-plus mr-2 rtl:ml-2 rtl:mr-0"></i>
          <span>{t('common.newPost')}</span>
        </Button>
        
        {/* Language toggle button */}
        <Button 
          variant="ghost" 
          className="text-neutral-600 hover:text-neutral-900 bg-neutral-50 w-10 h-10 rounded-full flex items-center justify-center"
          onClick={toggleLanguage}
        >
          <span className="text-sm font-medium">{i18n.language === 'en' ? 'EN' : 'عر'}</span>
        </Button>
      </div>
    </header>
  );
}
