import { supabase } from '@/lib/supabase';
import { useTranslation } from 'react-i18next';
import { Button } from '@/components/ui/button';
import { FaGoogle } from 'react-icons/fa';
import { useState } from 'react';

interface GoogleAuthFormProps {
  view?: 'sign_in' | 'sign_up';
}

export default function GoogleAuthForm({ view = 'sign_in' }: GoogleAuthFormProps) {
  const { t } = useTranslation();
  const [loading, setLoading] = useState(false);
  
  const handleGoogleSignIn = async () => {
    setLoading(true);
    try {
      await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: {
          redirectTo: `${window.location.origin}/auth/callback`
        }
      });
    } catch (error) {
      console.error('Google auth error:', error);
    } finally {
      setLoading(false);
    }
  };
  
  return (
    <div className="w-full">
      <Button 
        variant="outline" 
        className="w-full justify-center gap-2" 
        onClick={handleGoogleSignIn}
        disabled={loading}
      >
        {loading ? (
          <div className="h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent"></div>
        ) : (
          <>
            <FaGoogle className="h-4 w-4" />
            {view === 'sign_in' ? t('auth.signInWithGoogle', 'Sign in with Google') : t('auth.signUpWithGoogle', 'Sign up with Google')}
          </>
        )}
      </Button>
    </div>
  );
}