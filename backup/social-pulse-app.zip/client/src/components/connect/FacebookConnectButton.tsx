import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { apiRequest } from "@/lib/queryClient";
import { useTranslation } from "react-i18next";

export default function FacebookConnectButton({ onSuccess }: { onSuccess?: () => void }) {
  const [isConnecting, setIsConnecting] = useState(false);
  const [authWindow, setAuthWindow] = useState<Window | null>(null);
  const { toast } = useToast();
  const { t } = useTranslation();

  // Handle OAuth callback
  useEffect(() => {
    // Function to process incoming messages from the auth popup
    const handleAuthMessage = (event: MessageEvent) => {
      // Only process messages from our domains
      const isTrustedOrigin = event.origin === window.location.origin;
      
      if (isTrustedOrigin && event.data && typeof event.data === 'object' && event.data.type === 'facebook_auth_callback') {
        // If we get a callback message, close the auth window and process the data
        if (authWindow) {
          authWindow.close();
          setAuthWindow(null);
        }
        
        // Handle Facebook auth code
        if (event.data.code) {
          handleFacebookCallback(event.data.code);
        } else if (event.data.error) {
          // Handle error
          toast({
            title: t("connect.errorTitle"),
            description: event.data.error || t("connect.facebook.authError"),
            variant: "destructive",
          });
          setIsConnecting(false);
        }
      }
    };

    // Add event listener for messages
    window.addEventListener('message', handleAuthMessage);
    
    // Cleanup
    return () => {
      window.removeEventListener('message', handleAuthMessage);
    };
  }, [authWindow, toast, t]);

  // Handle OAuth code exchange
  const handleFacebookCallback = async (code: string) => {
    try {
      const response = await apiRequest("POST", "/api/facebook/callback", { code });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to complete Facebook authorization");
      }
      
      const accountData = await response.json();
      
      toast({
        title: t("connect.successTitle"),
        description: t("connect.facebook.accountConnected", "Your Facebook account has been connected successfully."),
      });
      
      if (onSuccess) {
        onSuccess();
      }
    } catch (error: any) {
      console.error("Facebook callback error:", error);
      
      toast({
        title: t("connect.errorTitle"),
        description: error.message || t("connect.facebook.authError", "Failed to connect Facebook"),
        variant: "destructive",
      });
    } finally {
      setIsConnecting(false);
    }
  };

  // Initialize OAuth flow
  const handleConnect = async () => {
    setIsConnecting(true);
    try {
      // Get auth URL from server
      const response = await apiRequest("GET", "/api/facebook/auth");
      
      if (!response.ok) {
        const errorData = await response.json();
        
        // Special handling for missing API credentials
        if (errorData.errorType === "CREDENTIALS_MISSING") {
          throw new Error("Facebook API credentials are not configured. Please contact support.");
        }
        
        throw new Error(errorData.message || "Failed to start Facebook authorization");
      }
      
      const { authUrl, state } = await response.json();
      
      // Open auth popup
      const width = 600;
      const height = 700;
      const left = window.screenX + (window.outerWidth - width) / 2;
      const top = window.screenY + (window.outerHeight - height) / 2;
      
      const authPopup = window.open(
        authUrl, 
        "facebook-auth-popup",
        `width=${width},height=${height},left=${left},top=${top},resizable,scrollbars=yes,status=1`
      );
      
      if (!authPopup) {
        throw new Error("Popup blocked. Please allow popups and try again.");
      }
      
      setAuthWindow(authPopup);
      
      // Monitor popup
      const checkClosed = setInterval(() => {
        if (authPopup.closed) {
          clearInterval(checkClosed);
          if (isConnecting) {
            setIsConnecting(false);
            toast({
              title: t("connect.cancelledTitle"),
              description: t("connect.facebook.authCancelled", "Facebook authentication was cancelled."),
              variant: "default",
            });
          }
        }
      }, 500);
      
    } catch (error: any) {
      console.error("Facebook auth error:", error);
      
      toast({
        title: t("connect.errorTitle"),
        description: error.message || t("connect.facebook.authError", "Failed to connect Facebook"),
        variant: "destructive",
      });
      setIsConnecting(false);
    }
  };

  return (
    <Button 
      onClick={handleConnect} 
      disabled={isConnecting}
      className="flex items-center space-x-2 rtl:space-x-reverse"
    >
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="16"
        height="16"
        viewBox="0 0 24 24"
        fill="currentColor"
        className="inline-block"
      >
        <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
      </svg>
      <span>
        {isConnecting ? t("connect.facebook.connecting", "Connecting...") : t("connect.facebook.connect", "Connect Facebook")}
      </span>
    </Button>
  );
}