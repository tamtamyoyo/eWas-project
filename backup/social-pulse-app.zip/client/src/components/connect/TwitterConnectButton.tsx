import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { apiRequest } from "@/lib/queryClient";
import { useTranslation } from "react-i18next";

export default function TwitterConnectButton({ onSuccess }: { onSuccess?: () => void }) {
  const [isConnecting, setIsConnecting] = useState(false);
  const { toast } = useToast();
  const { t } = useTranslation();

  const handleConnect = async () => {
    setIsConnecting(true);
    try {
      // First, check if the user is authenticated
      const userResponse = await apiRequest("GET", "/api/auth/user");
      if (!userResponse.ok) {
        const errorData = await userResponse.json();
        throw new Error(errorData.message || "Please log in first");
      }

      // Now request Twitter auth
      const response = await apiRequest("GET", "/api/twitter/auth");
      
      if (!response.ok) {
        const errorData = await response.json();
        
        // Check for specific error types and provide helpful messages
        if (errorData.message?.includes('API authentication failed') || errorData.message?.includes('Could not authenticate you')) {
          throw new Error(t("connect.twitter.apiKeyError"));
        } else if (errorData.message?.includes('callback URL')) {
          throw new Error(t("connect.twitter.callbackUrlError"));
        } else {
          throw new Error(errorData.message || t("connect.twitter.authError"));
        }
      }
      
      const data = await response.json();
      
      // Store oauth_token and oauth_token_secret for the callback
      if (data.oauth_token && data.oauth_token_secret) {
        localStorage.setItem("twitter_oauth_token", data.oauth_token);
        localStorage.setItem("twitter_oauth_token_secret", data.oauth_token_secret);
      } else {
        throw new Error(t("connect.twitter.missingTokens"));
      }
      
      // Redirect user to Twitter auth page
      if (data.authUrl) {
        window.location.href = data.authUrl;
      } else {
        throw new Error(t("connect.twitter.missingAuthUrl"));
      }
      
    } catch (error: any) {
      console.error("Twitter auth error:", error);
      setIsConnecting(false);
      
      toast({
        title: t("connect.errorTitle"),
        description: error.message || t("connect.twitter.authError"),
        variant: "destructive",
      });
    }
  };

  return (
    <Button 
      onClick={handleConnect} 
      disabled={isConnecting}
      className="flex items-center space-x-2 rtl:space-x-reverse"
    >
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="16"
        height="16"
        viewBox="0 0 24 24"
        fill="currentColor"
        className="inline-block"
      >
        <path d="M14.258 10.152L23.176 0h-2.113l-7.747 8.813L7.133 0H0l9.352 13.328L0 23.973h2.113l8.176-9.309 6.531 9.309h7.133zm-2.895 3.293l-.949-1.328L2.875 1.56h3.246l6.086 8.523.945 1.328 7.91 11.078h-3.246z" />
      </svg>
      <span>
        {isConnecting ? t("connect.twitter.connecting") : t("connect.twitter.connect")}
      </span>
    </Button>
  );
}