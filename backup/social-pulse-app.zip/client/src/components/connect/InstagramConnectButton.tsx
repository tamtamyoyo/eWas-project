import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { apiRequest } from "@/lib/queryClient";
import { useTranslation } from "react-i18next";

export default function InstagramConnectButton({ onSuccess }: { onSuccess?: () => void }) {
  const [isConnecting, setIsConnecting] = useState(false);
  const [authWindow, setAuthWindow] = useState<Window | null>(null);
  const { toast } = useToast();
  const { t } = useTranslation();

  // Handle OAuth callback
  useEffect(() => {
    // Function to process incoming messages from the auth popup
    const handleAuthMessage = (event: MessageEvent) => {
      // Only process messages from our domains
      const isTrustedOrigin = event.origin === window.location.origin;
      
      if (isTrustedOrigin && event.data && typeof event.data === 'object' && event.data.type === 'instagram_auth_callback') {
        // If we get a callback message, close the auth window and process the data
        if (authWindow) {
          authWindow.close();
          setAuthWindow(null);
        }
        
        // Handle Instagram auth code
        if (event.data.code) {
          handleInstagramCallback(event.data.code);
        } else if (event.data.error) {
          // Handle error
          toast({
            title: t("connect.errorTitle"),
            description: event.data.error || t("connect.instagram.authError"),
            variant: "destructive",
          });
          setIsConnecting(false);
        }
      }
    };

    // Add event listener for messages
    window.addEventListener('message', handleAuthMessage);
    
    // Cleanup
    return () => {
      window.removeEventListener('message', handleAuthMessage);
    };
  }, [authWindow, toast, t]);

  // Handle OAuth code exchange
  const handleInstagramCallback = async (code: string) => {
    try {
      const response = await apiRequest("POST", "/api/instagram/callback", { code });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to complete Instagram authorization");
      }
      
      const accountData = await response.json();
      
      toast({
        title: t("connect.successTitle"),
        description: t("connect.instagram.accountConnected", "Your Instagram account has been connected successfully."),
      });
      
      if (onSuccess) {
        onSuccess();
      }
    } catch (error: any) {
      console.error("Instagram callback error:", error);
      
      toast({
        title: t("connect.errorTitle"),
        description: error.message || t("connect.instagram.authError", "Failed to connect Instagram"),
        variant: "destructive",
      });
    } finally {
      setIsConnecting(false);
    }
  };

  // Initialize OAuth flow
  const handleConnect = async () => {
    setIsConnecting(true);
    try {
      // Get auth URL from server
      const response = await apiRequest("GET", "/api/instagram/auth");
      
      if (!response.ok) {
        const errorData = await response.json();
        
        // Special handling for missing API credentials
        if (errorData.errorType === "CREDENTIALS_MISSING") {
          throw new Error("Instagram API credentials are not configured. Please contact support.");
        }
        
        throw new Error(errorData.message || "Failed to start Instagram authorization");
      }
      
      const { authUrl, state } = await response.json();
      
      // Open auth popup
      const width = 600;
      const height = 700;
      const left = window.screenX + (window.outerWidth - width) / 2;
      const top = window.screenY + (window.outerHeight - height) / 2;
      
      const authPopup = window.open(
        authUrl, 
        "instagram-auth-popup",
        `width=${width},height=${height},left=${left},top=${top},resizable,scrollbars=yes,status=1`
      );
      
      if (!authPopup) {
        throw new Error("Popup blocked. Please allow popups and try again.");
      }
      
      setAuthWindow(authPopup);
      
      // Monitor popup
      const checkClosed = setInterval(() => {
        if (authPopup.closed) {
          clearInterval(checkClosed);
          if (isConnecting) {
            setIsConnecting(false);
            toast({
              title: t("connect.cancelledTitle"),
              description: t("connect.instagram.authCancelled", "Instagram authentication was cancelled."),
              variant: "default",
            });
          }
        }
      }, 500);
      
    } catch (error: any) {
      console.error("Instagram auth error:", error);
      
      toast({
        title: t("connect.errorTitle"),
        description: error.message || t("connect.instagram.authError", "Failed to connect Instagram"),
        variant: "destructive",
      });
      setIsConnecting(false);
    }
  };

  return (
    <Button 
      onClick={handleConnect} 
      disabled={isConnecting}
      className="flex items-center space-x-2 rtl:space-x-reverse"
    >
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="16"
        height="16"
        viewBox="0 0 24 24"
        fill="currentColor"
        className="inline-block"
      >
        <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z" />
      </svg>
      <span>
        {isConnecting ? t("connect.instagram.connecting", "Connecting...") : t("connect.instagram.connect", "Connect Instagram")}
      </span>
    </Button>
  );
}