import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import LanguageDetector from 'i18next-browser-languagedetector';
import enTranslation from './locales/en.json';
import arTranslation from './locales/ar.json';

i18n
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    resources: {
      en: {
        translation: enTranslation
      },
      ar: {
        translation: arTranslation
      }
    },
    fallbackLng: 'en',
    interpolation: {
      escapeValue: false // React already safes from XSS
    },
    detection: {
      order: ['localStorage', 'navigator'],
      lookupLocalStorage: 'socialPulseLanguage',
      caches: ['localStorage']
    },
    debug: true, // Enable debug mode to help identify missing translations
    saveMissing: true, // Save missing translations to help with development
    missingKeyHandler: (lng, ns, key, fallbackValue) => {
      console.warn(`Missing translation key: ${key} for language: ${lng} in namespace: ${ns}`);
    }
  });

// Function to set HTML dir attribute and lang based on language
export const setDocumentLanguage = (language: string) => {
  const htmlElement = document.documentElement;
  
  if (language === 'ar') {
    htmlElement.setAttribute('dir', 'rtl');
    htmlElement.setAttribute('lang', 'ar');
  } else {
    htmlElement.setAttribute('dir', 'ltr');
    htmlElement.setAttribute('lang', 'en');
  }
};

// Set initial direction based on current language
setDocumentLanguage(i18n.language);

// Listen for language changes
i18n.on('languageChanged', (lang) => {
  setDocumentLanguage(lang);
});

export default i18n;
